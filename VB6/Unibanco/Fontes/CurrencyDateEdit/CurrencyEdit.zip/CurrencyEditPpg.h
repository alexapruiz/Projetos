#if !defined(AFX_CURRENCYEDITPPG_H__ED49B8F7_E38A_11D3_9FFC_00104BC8688C__INCLUDED_)
#define AFX_CURRENCYEDITPPG_H__ED49B8F7_E38A_11D3_9FFC_00104BC8688C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// CurrencyEditPpg.h : Declaration of the CCurrencyEditPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CCurrencyEditPropPage : See CurrencyEditPpg.cpp.cpp for implementation.

class CCurrencyEditPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CCurrencyEditPropPage)
	DECLARE_OLECREATE_EX(CCurrencyEditPropPage)

// Constructor
public:
	CCurrencyEditPropPage();

// Dialog Data
	//{{AFX_DATA(CCurrencyEditPropPage)
	enum { IDD = IDD_PROPPAGE_CURRENCYEDIT };
	BOOL	m_ExibirZero;
	short	m_MaxLength;
	CString	m_Text;
	BOOL	m_Locked;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CCurrencyEditPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CURRENCYEDITPPG_H__ED49B8F7_E38A_11D3_9FFC_00104BC8688C__INCLUDED)
