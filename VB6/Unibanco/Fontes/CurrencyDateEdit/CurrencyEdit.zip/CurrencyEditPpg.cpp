// CurrencyEditPpg.cpp : Implementation of the CCurrencyEditPropPage property page class.

#include "stdafx.h"
#include "CurrencyEdit.h"
#include "CurrencyEditPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CCurrencyEditPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CCurrencyEditPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CCurrencyEditPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CCurrencyEditPropPage, "CURRENCYEDIT.CurrencyEditPropPage.1",
	0xed49b8e8, 0xe38a, 0x11d3, 0x9f, 0xfc, 0, 0x10, 0x4b, 0xc8, 0x68, 0x8c)


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditPropPage::CCurrencyEditPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CCurrencyEditPropPage

BOOL CCurrencyEditPropPage::CCurrencyEditPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_CURRENCYEDIT_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditPropPage::CCurrencyEditPropPage - Constructor

CCurrencyEditPropPage::CCurrencyEditPropPage() :
	COlePropertyPage(IDD, IDS_CURRENCYEDIT_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CCurrencyEditPropPage)
	m_ExibirZero = FALSE;
	m_MaxLength = 0;
	m_Text = _T("");
	m_Locked = FALSE;
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditPropPage::DoDataExchange - Moves data between page and properties

void CCurrencyEditPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CCurrencyEditPropPage)
	DDP_Check(pDX, IDC_CHECK_EXIBIRZERO, m_ExibirZero, _T("ExibirZero") );
	DDX_Check(pDX, IDC_CHECK_EXIBIRZERO, m_ExibirZero);
	DDP_Text(pDX, IDC_EDIT_MAXLENGTH, m_MaxLength, _T("MaxLength") );
	DDX_Text(pDX, IDC_EDIT_MAXLENGTH, m_MaxLength);
	DDV_MinMaxInt(pDX, m_MaxLength, 0, MAX_LEN_NUMBER);
	DDP_Text(pDX, IDC_EDIT_TEXT, m_Text, _T("Text") );
	DDX_Text(pDX, IDC_EDIT_TEXT, m_Text);
	DDP_Check(pDX, IDC_CHECK_LOCKED, m_Locked, _T("Locked") );
	DDX_Check(pDX, IDC_CHECK_LOCKED, m_Locked);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditPropPage message handlers
