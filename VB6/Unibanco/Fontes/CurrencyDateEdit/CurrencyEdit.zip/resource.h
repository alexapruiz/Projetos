//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CurrencyEdit.rc
//
#define IDS_CURRENCYEDIT                1
#define IDD_ABOUTBOX_CURRENCYEDIT       1
#define IDB_CURRENCYEDIT                1
#define IDI_ABOUTDLL                    1
#define IDS_CURRENCYEDIT_PPG            2
#define IDS_CURRENCYEDIT_PPG_CAPTION    200
#define IDD_PROPPAGE_CURRENCYEDIT       200
#define IDC_CHECK_EXIBIRZERO            201
#define IDC_EDIT_MAXLENGTH              202
#define IDC_EDIT_TEXT                   203
#define IDC_CHECK_LOCKED                204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
