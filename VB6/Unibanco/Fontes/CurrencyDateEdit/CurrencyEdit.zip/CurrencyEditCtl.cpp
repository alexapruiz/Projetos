// CurrencyEditCtl.cpp : Implementation of the CCurrencyEditCtrl ActiveX Control class.

#include "stdafx.h"
#include "CurrencyEdit.h"
#include "CurrencyEditCtl.h"
#include "CurrencyEditPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CCurrencyEditCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CCurrencyEditCtrl, COleControl)
	//{{AFX_MSG_MAP(CCurrencyEditCtrl)
	ON_WM_SETFOCUS()
	ON_WM_SETCURSOR()
	ON_WM_KILLFOCUS()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_ENABLE()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_EDIT, OnEdit)
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CCurrencyEditCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CCurrencyEditCtrl)
	DISP_PROPERTY_EX(CCurrencyEditCtrl, "ExibirZero", GetExibirZero, SetExibirZero, VT_BOOL)
	DISP_PROPERTY_EX(CCurrencyEditCtrl, "MaxLength", GetMaxLength, SetMaxLength, VT_I2)
	DISP_PROPERTY_EX(CCurrencyEditCtrl, "Locked", GetLocked, SetLocked, VT_BOOL)
	DISP_PROPERTY_EX(CCurrencyEditCtrl, "SelStart", GetSelStart, SetSelStart, VT_I2)
	DISP_PROPERTY_EX(CCurrencyEditCtrl, "SelLength", GetSelLength, SetSelLength, VT_I2)
	DISP_STOCKPROP_ENABLED()
	DISP_STOCKPROP_FONT()
	DISP_STOCKPROP_FORECOLOR()
	DISP_PROPERTY_EX_ID(CCurrencyEditCtrl, "BackColor", DISPID_BACKCOLOR, GetBackColor, SetBackColor, VT_COLOR)
	DISP_PROPERTY_EX_ID(CCurrencyEditCtrl, "Text", DISPID_TEXT, GetText, SetText, VT_BSTR)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CCurrencyEditCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CCurrencyEditCtrl, COleControl)
	//{{AFX_EVENT_MAP(CCurrencyEditCtrl)
	EVENT_STOCK_CLICK()
	EVENT_STOCK_DBLCLICK()
	EVENT_STOCK_KEYDOWN()
	EVENT_STOCK_KEYPRESS()
	EVENT_STOCK_KEYUP()
	EVENT_STOCK_MOUSEDOWN()
	EVENT_STOCK_MOUSEMOVE()
	EVENT_STOCK_MOUSEUP()
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CCurrencyEditCtrl, 3)
	PROPPAGEID(CCurrencyEditPropPage::guid)
	PROPPAGEID(CLSID_CColorPropPage)
	PROPPAGEID(CLSID_CFontPropPage)
END_PROPPAGEIDS(CCurrencyEditCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CCurrencyEditCtrl, "CURRENCYEDIT.CurrencyEditCtrl.1",
	0x9cba5d67, 0xe3c8, 0x11d3, 0x9f, 0xfc, 0, 0x10, 0x4b, 0xc8, 0x68, 0x8c)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CCurrencyEditCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DCurrencyEdit =
		{ 0x9cba5d65, 0xe3c8, 0x11d3, { 0x9f, 0xfc, 0, 0x10, 0x4b, 0xc8, 0x68, 0x8c } };
const IID BASED_CODE IID_DCurrencyEditEvents =
		{ 0x9cba5d66, 0xe3c8, 0x11d3, { 0x9f, 0xfc, 0, 0x10, 0x4b, 0xc8, 0x68, 0x8c } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwCurrencyEditOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CCurrencyEditCtrl, IDS_CURRENCYEDIT, _dwCurrencyEditOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditCtrl::CCurrencyEditCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CCurrencyEditCtrl

BOOL CCurrencyEditCtrl::CCurrencyEditCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegInsertable | afxRegApartmentThreading to afxRegInsertable.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_CURRENCYEDIT,
			IDB_CURRENCYEDIT,
			afxRegInsertable | afxRegApartmentThreading,
			_dwCurrencyEditOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditCtrl::CCurrencyEditCtrl - Constructor

CCurrencyEditCtrl::CCurrencyEditCtrl()
{
	InitializeIIDs(&IID_DCurrencyEdit, &IID_DCurrencyEditEvents);

	SetInitialSize(85, 20);
	m_DeslPrimChar  = 3;
	m_Align         = 1;
	m_MaxLength     = 0;
	m_HasFocus      = false;
	m_Exibir000     = true;
	m_Selecting     = false;
	m_SelBegin      = -1;
    m_Insert        = true;
    m_IncrCaret     = 0;
    m_EditPos       = 0;
	m_Locked        = false;

    strcpy(m_Picture,"###.###.###.###.###.###.###.###.###.###.###.###,##");

	mPenGray.CreatePen(PS_SOLID, 1, RGB(128, 128, 128));
	mPenLtGray.CreatePen(PS_SOLID, 1, RGB(192, 192, 192));
	mPenWhite.CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
	mPenBlack.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));

}


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditCtrl::~CCurrencyEditCtrl - Destructor

CCurrencyEditCtrl::~CCurrencyEditCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditCtrl::OnDraw - Drawing function

void CCurrencyEditCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
    int i, SelBeginAux,SelEndAux;
	CBrush mBrush(TranslateColor(GetBackColor()));
	CRect r(rcBounds);
    CFont *m_Font;

    if(m_HasFocus)
    {
        DestroyCaret();
    }

	m_Font = SelectStockFont(pdc);
    CSize size=pdc->GetTextExtent((const char*)"5",1);
    m_CharWidth  = size.cx;
	m_CharHeight = size.cy;

	if( m_MaxLength == 0 )
	{
       m_MaxNumChar=0;
		for(i = 0; i < (int)strlen(m_Picture); i++)
		{
			if(m_Picture[i]=='#')
				m_MaxNumChar++;
		}
	}
	else
	{
		m_MaxNumChar = m_MaxLength;
	}

	pdc->SetTextAlign(TA_LEFT|TA_TOP);
    pdc->SetBkColor(TranslateColor(GetBackColor()));

    m_IncrCaret=0; // incremento no caret para coloc�-lo na posi��o correta. Pulando os . e ,.

    int NumCharBufferAux=m_Text.GetLength();
    char BufferAux[MAX_NUM_CHAR_BUFFER];
    (void)strcpy(BufferAux,LPCTSTR(m_Text));

    if(m_Exibir000)
    {
        if(strlen(BufferAux)==0)
        {
            strcpy(BufferAux,"000");
            NumCharBufferAux=3;
        }
        else if(strlen(BufferAux)==1)
        {
            BufferAux[0]='0';
            BufferAux[1]='0';
            BufferAux[2]=0;
            strcat(BufferAux,LPCTSTR(m_Text));
            NumCharBufferAux=3;
        }
        else if(strlen(BufferAux)==2)
        {
            BufferAux[0]='0';
            BufferAux[1]=0;
            strcat(BufferAux,LPCTSTR(m_Text));
            NumCharBufferAux=3;
        }
    }

    int index=1;
    m_FmtText[0]=BufferAux[0];

    // criar a faixa na string formatada!
    // tem faixa marcada?
    if(m_SelBegin!=-1)
    {
        // estou colocando na string formatada o 1o. caracter da faixa?
        if(0==m_SelBegin)
            SelBeginAux=0;
        // estou colocando na string formatada o �ltimo caracter da faixa?
        if(0==m_SelEnd)
            SelEndAux=0;
    }
    for(i=1; i<=NumCharBufferAux; i++)
    {
        if(NumCharBufferAux-i==2)
        {
            m_FmtText[index++]=',';
            // estou inserindo um caractere antes da posi��o de edi��o?
            if(i<=m_EditPos)
                m_IncrCaret++;
        }
        else
        {
            if((NumCharBufferAux-i-2)%3==0 && NumCharBufferAux-i>3)
            {
                m_FmtText[index++]='.';
                // estou inserindo um caractere antes da posi��o de edi��o?
                if(i<=m_EditPos)
                    m_IncrCaret++;
            }
        }
        m_FmtText[index++]=BufferAux[i];

        // criar a faixa na string formatada!
        // tem faixa marcada?
        if(m_SelBegin!=-1)
        {
            // estou colocando na string formatada o 1o. caracter da faixa?
            if(i==m_SelBegin)
                SelBeginAux=index-1;
            // estou colocando na string formatada o �ltimo caracter da faixa?
            if(i==m_SelEnd)
                SelEndAux=index-1;
        }
    }

    if(m_Exibir000)
    {
        if(m_Text.GetLength()==0)
		{
            m_IncrCaret=4;
            if(m_SelBegin!=-1)
            {
                SelBeginAux=0;
                SelEndAux=3;
            }
		}
        else if(m_Text.GetLength()==1)
        {
            m_IncrCaret=3;
            if(m_SelBegin!=-1)
            {
                SelBeginAux=0;
                SelEndAux=3;
            }
        }
        else if(m_Text.GetLength()==2)
        {
            m_IncrCaret=2;
            if(m_SelBegin!=-1)
            {
                if(m_SelBegin==0 && m_SelEnd==0)
                {
                    SelBeginAux=0;
                    SelEndAux=2;
                }
                else
                {
                    SelBeginAux=0;
                    SelEndAux=3;
                }
            }
        }
    }

    int TamTextoPixel=m_CharWidth*strlen(m_FmtText);
    //alinhamento a esquerda?
    if(m_Align==0)
        m_DeslPrimChar=3;
    else m_DeslPrimChar=r.right-TamTextoPixel-3-m_CharWidth;

    pdc->FillRect(r,&mBrush);

    if(m_SelBegin!=-1 && m_HasFocus)
    {
        CRect r(rcBounds);
        r.top+=3;
        r.bottom-=3;

        r.left  = m_DeslPrimChar+SelBeginAux*m_CharWidth;
        r.right = m_DeslPrimChar+(SelEndAux+1)*m_CharWidth;
        pdc->FillSolidRect(r,RGB(0, 0, 128));
    }

    pdc->SetBkMode(TRANSPARENT);

    for(i=0; i<(int)(strlen(m_FmtText)); i++)
    {
        // controle desabilitado?
        if(!IsWindowEnabled())
            pdc->SetTextColor(RGB(192, 192, 192));
        else
        {
            // tem faixa selecionada e o caracter atual est� na faixa?
            if(m_SelBegin!=-1 && (SelBeginAux<=i && i<=SelEndAux) && m_HasFocus)
            {
                pdc->SetTextColor(RGB(255, 255, 255));
            }
            else
            {
                pdc->SetTextColor(TranslateColor(GetForeColor()));
            }
        }
        pdc->TextOut(m_DeslPrimChar+i*m_CharWidth,(r.top+2),m_FmtText+i,1);
    }

    // desenhar Bordas!
    pdc->SelectObject(mPenGray);
    pdc->MoveTo(0,0);
    pdc->LineTo(r.right-2,0);
    pdc->MoveTo(0,0);
    pdc->LineTo(0,r.bottom-2);

    pdc->SelectObject(mPenBlack);
    pdc->MoveTo(1,1);
    pdc->LineTo(r.right-2,1);
    pdc->MoveTo(1,1);
    pdc->LineTo(1,r.bottom-2);

    pdc->SelectObject(mPenLtGray);
    pdc->MoveTo(r.right-2,1);
    pdc->LineTo(r.right-2,r.bottom-2);
    pdc->MoveTo(1,r.bottom-2);
    pdc->LineTo(r.right-1,r.bottom-2);

    pdc->SelectObject(mPenWhite);
    pdc->MoveTo(r.right-1,0);
    pdc->LineTo(r.right-1,r.bottom-1);
    pdc->MoveTo(0,r.bottom-1);
    pdc->LineTo(r.right-1,r.bottom-1);

    if(m_HasFocus)
    {
        if(!m_Insert)
        {
            ::CreateCaret(m_hWnd,NULL,m_CharWidth,m_CharHeight-2);
        }
        else
        {
            ::CreateCaret(m_hWnd, NULL, 2, m_CharHeight-2);
        }

        ::SetCaretPos(m_DeslPrimChar+(m_EditPos+m_IncrCaret)*m_CharWidth,3);
        ShowCaret();
    }

	pdc->SelectObject(m_Font);

}


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditCtrl::DoPropExchange - Persistence support

void CCurrencyEditCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	if (pPX->GetVersion() == (DWORD)MAKELONG(_wVerMinor, _wVerMajor))
	{
    	PX_String(pPX, _T("Text"), m_Text, _T(""));
    	PX_Bool(pPX, _T("ExibirZero"), m_Exibir000, TRUE);
		PX_Short(pPX, _T("MaxLength"), m_MaxLength, 0);
		PX_Color(pPX, _T("BackColor"), m_BackColor, RGB(255, 255, 255));
		PX_Bool(pPX, _T("Locked"), m_Locked, false);
		PX_Short(pPX, _T("SelStart"), m_SelStart, 0);
		PX_Short(pPX, _T("SelLength"), m_SelLength, 0);
	}
	else if (pPX->IsLoading())
	{
		CString strDummy;
		BOOL bDummy;
		short nDummy;
		OLE_COLOR cDummy;
		short sDummy;
		PX_String(pPX, _T("Text"), strDummy, _T(""));
		PX_Bool(pPX, _T("ExibirZero"), bDummy, FALSE);
		PX_Short(pPX, _T("MaxLength"), nDummy, 0);
		PX_Color(pPX, _T("BackColor"), cDummy, RGB(255, 255, 255));
		PX_Bool(pPX, _T("Locked"), bDummy, false);
		PX_Short(pPX, _T("SelStart"), sDummy, 0);
		PX_Short(pPX, _T("SelLength"), sDummy, 0);

		m_Text = _T("");
		m_Exibir000 = TRUE;
		m_MaxLength = 0;
		m_BackColor = RGB(255, 255, 255);
		m_Locked = false;
		m_SelStart = 0;
		m_SelLength = 0;
	}

}


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditCtrl::OnResetState - Reset control to default state

void CCurrencyEditCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditCtrl::AboutBox - Display an "About" box to the user

void CCurrencyEditCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_CURRENCYEDIT);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CCurrencyEditCtrl message handlers

void CCurrencyEditCtrl::OnSetFocus(CWnd* pOldWnd) 
{
    if (!m_HasFocus)
    {
        m_HasFocus=true;
       // em insert mode?
        if(!m_Insert)
        {
            ::CreateCaret(m_hWnd, NULL,m_CharWidth,m_CharHeight-2);
        }
        else
        {
            ::CreateCaret(m_hWnd, NULL,2,m_CharHeight-2);
        }

		if( m_Text.GetLength() > 0 )
		{
			m_SelBegin = 0;
			m_SelEnd = m_Text.GetLength() - 1;
		}

        ::SetCaretPos(m_DeslPrimChar+(m_EditPos+m_IncrCaret)*m_CharWidth,3);
        ShowCaret();
    }
    InvalidateControl();

	COleControl::OnSetFocus(pOldWnd);
}

BOOL CCurrencyEditCtrl::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
    // S� iremos cuidar dos eventos na �rea cliente!
    if(nHitTest==HTCLIENT)
    {
        HCURSOR h=::LoadCursor(NULL,IDC_IBEAM);
        ::SetCursor(h);
        return TRUE;
    }
	return COleControl::OnSetCursor(pWnd, nHitTest, message);
}

void CCurrencyEditCtrl::OnKillFocus(CWnd* pNewWnd) 
{
    if (m_HasFocus)
    {
        m_HasFocus=false;
        DestroyCaret();
        InvalidateControl();
    }

	COleControl::OnKillFocus(pNewWnd);
	
}

void CCurrencyEditCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if( m_Locked )
	{
		COleControl::OnKeyDown(nChar, nRepCnt, nFlags);
		return;
	}

	// Digitos de 0 a 9?
    if( (nChar>=0x30 && nChar<=0x39) ||
        (nChar>=0x60 && nChar<=0x69) )
    {
        if(nChar>0x39)
            nChar-=0x30;

        // modo overwrite?
        if(!m_Insert)
        {

            // h� faixa selecionada?
            if(m_SelBegin!=-1)
            {
				m_Text = m_Text.Left(m_SelBegin) + m_Text.Right(m_Text.GetLength()-(m_SelEnd+1));
                m_EditPos=m_SelBegin;
                m_SelBegin=-1;
            }

            // estou editando ap�s o �ltimo caractere no buffer?
            if(m_EditPos==m_Text.GetLength())
            {   // na verdade � insert no final do buffer!
				MessageBeep(MB_OK);
            }
            else
            {
				m_Text.SetAt(m_EditPos, (char)nChar);
                m_EditPos++;
            }
            InvalidateControl();
        }
        else
        {   // modo insert!

            // h� faixa selecionada?
            if(m_SelBegin!=-1)
            {
				m_Text = m_Text.Left(m_SelBegin) + m_Text.Right(m_Text.GetLength()-(m_SelEnd+1));
                m_EditPos=m_SelBegin;
                m_SelBegin=-1;
            }

            // buffer n�o est� cheio?
            if(m_Text.GetLength()<m_MaxNumChar)
            {
				m_Text = m_Text.Left(m_EditPos) + (char)nChar + m_Text.Right(m_Text.GetLength()-(m_EditPos));
                m_EditPos++;

                InvalidateControl();
            }
            else MessageBeep(MB_OK);
        }
        return;
    }

    switch(nChar)
    {
    case VK_DECIMAL:
        PostMessage(WM_KEYDOWN, VK_NUMPAD0, 0);
        PostMessage(WM_KEYDOWN, VK_NUMPAD0, 0);
        break;
    case VK_UP:
    case VK_LEFT:
        if(0<m_EditPos)
        {
            m_EditPos--;
            m_SelBegin=-1;
            InvalidateControl();
        }
        break;
    case VK_DOWN:
    case VK_RIGHT:
        if(m_EditPos<m_Text.GetLength())
        {
            m_EditPos++;
            m_SelBegin=-1;
            InvalidateControl();
        }
        break;

    case VK_INSERT:
        if (m_HasFocus)
        {
            DestroyCaret();
            // estava em modo de insert?
            if(m_Insert)
            {   // entra em overwrite!
                m_Insert=false;
                ::CreateCaret(m_hWnd, NULL,m_CharWidth,m_CharHeight-2);
            }
            else
            {   // entra em insert mode!
                m_Insert=true;
                ::CreateCaret(m_hWnd, NULL,2,m_CharHeight-2);
            }
            ::SetCaretPos(m_DeslPrimChar+(m_EditPos+m_IncrCaret)*m_CharWidth,3);
            ShowCaret();
        }
        break;

    case VK_DELETE:
    {
        // h� faixa selecionada?
        if(m_SelBegin!=-1)
        {
    		m_Text = m_Text.Left(m_SelBegin) + m_Text.Right(m_Text.GetLength()-(m_SelEnd+1));
            m_EditPos=m_SelBegin;
            m_SelBegin=-1;
            InvalidateControl();
            break;
        }

        if(m_EditPos==m_Text.GetLength())
        {
            m_SelBegin=-1;
            MessageBeep(MB_OK);
            break;
        }

        m_Text = m_Text.Left(m_EditPos) + m_Text.Right(m_Text.GetLength()-(m_EditPos + 1));
        InvalidateControl();
    }
        break;
    case VK_BACK:
        // h� faixa selecionada?
        if(m_SelBegin!=-1)
        {
    		m_Text = m_Text.Left(m_SelBegin) + m_Text.Right(m_Text.GetLength()-(m_SelEnd+1));
            m_EditPos=m_SelBegin;
            m_SelBegin=-1;
            InvalidateControl();
        }
        else if(0<m_EditPos)
        {
            m_Text = m_Text.Left(m_EditPos-1) + m_Text.Right(m_Text.GetLength()-m_EditPos);
            m_EditPos--;
            InvalidateControl();
        }
        else MessageBeep(MB_OK);
        break;

    case VK_HOME:
        // j� est� na 1a. posi��o?
        m_EditPos=0;
        m_SelBegin=-1;
        InvalidateControl();
        break;

    case VK_END:
        // j� est� no final?
        m_EditPos=m_Text.GetLength();
        m_SelBegin=-1;
        InvalidateControl();
        break;
/*
    case VK_ESCAPE:
    case VK_ADD:
        m_SelBegin=-1;
        Clear();
        InvalidateControl();
        // Volta caso estiver adiantado
        break;
*/
    default:
        break;
    }
    COleControl::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CCurrencyEditCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	COleControl::OnLButtonDblClk(nFlags, point);

    if(!m_Text.IsEmpty())
    {
        m_SelBegin=0;
        m_SelEnd=m_Text.GetLength()-1;
        InvalidateControl();
    }
}

void CCurrencyEditCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	COleControl::OnLButtonDown(nFlags, point);

    if(point.x<0)
        point.x=0;

    m_Selecting   = true;
    m_FirstPixelX = point.x;
    m_EditPos=FmtPosToRealPos(FisToLog(point.x));
    SetCapture();
    m_SelBegin=-1;
    InvalidateControl();
	
}

void CCurrencyEditCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	COleControl::OnLButtonUp(nFlags, point);

    if(!m_Selecting)
        return;

    m_Selecting=false;
    ReleaseCapture();
}

void CCurrencyEditCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	COleControl::OnMouseMove(nFlags, point);

    if(!m_Selecting)
        return;

    if(point.x<0)
        point.x=0;

    // moveu pouco?
    if(abs(m_FirstPixelX-point.x)<5)
        return;

    int End=FmtPosToRealPos(FisToLog(point.x));
    m_EditPos = End;

    if(m_Text.GetLength()<=End)
        End=m_Text.GetLength()-1;

    // n�o h� �rea marcada?
    if(m_SelBegin==-1)
    {
        m_SelBegin=m_SelEnd=End;
        m_PosBase=End;
    }
    else
    {
        int SelBeginAux,SelEndAux;
        if(End<m_PosBase)
        {
            SelBeginAux = End;
            SelEndAux   = m_PosBase;
        }
        else
        {
            SelBeginAux = m_PosBase;
            SelEndAux   = End;
        }

        if(m_SelBegin!=SelBeginAux || m_SelEnd!=SelEndAux)
        {
            m_SelBegin = SelBeginAux;
            m_SelEnd   = SelEndAux;
        }
        else return;
    }
    InvalidateControl();
}

void CCurrencyEditCtrl::OnEnable(BOOL bEnable) 
{
    if (m_HasFocus && !bEnable)
    {
        m_HasFocus=false;
        DestroyCaret();
    }

	COleControl::OnEnable(bEnable);
	
}


OLE_COLOR CCurrencyEditCtrl::GetBackColor() 
{
	return m_BackColor;
}

void CCurrencyEditCtrl::SetBackColor(OLE_COLOR nNewValue) 
{
	m_BackColor = nNewValue;

	SetModifiedFlag();
	InvalidateControl();
}

BSTR CCurrencyEditCtrl::GetText() 
{
	CString strResult(m_Text);

	return strResult.AllocSysString();
}

void CCurrencyEditCtrl::SetText(LPCTSTR lpszNewValue) 
{
    const char *p=lpszNewValue;
    // edi��o de valor?
        while(*p=='0')
            p++;
	m_Text = p;
    m_EditPos       = m_Text.GetLength();
    m_Insert        = true;
    m_IncrCaret     = 0;
    m_SelBegin      = -1; 
	SetModifiedFlag();
    InvalidateControl();
    BoundPropertyChanged(DISPID_TEXT);

}

BOOL CCurrencyEditCtrl::GetExibirZero() 
{
	return m_Exibir000;
}

void CCurrencyEditCtrl::SetExibirZero(BOOL bNewValue) 
{
	m_Exibir000 = bNewValue;

	InvalidateControl();
	SetModifiedFlag();
}

short CCurrencyEditCtrl::GetMaxLength() 
{
	return m_MaxLength;
}

void CCurrencyEditCtrl::SetMaxLength(short nNewValue) 
{
	if( (nNewValue >= 0) && (nNewValue <= MAX_LEN_NUMBER) )
	{
	  m_MaxLength = nNewValue;
	}
	else
	{
	  m_MaxLength = 0;
	}

	SetModifiedFlag();
    InvalidateControl();
    BoundPropertyChanged(dispidMaxLength);
}

void CCurrencyEditCtrl::Clear() 
{
	m_Text.Empty();
    m_EditPos       = 0;
    m_Insert        = true;
    m_IncrCaret     = 0;
    InvalidateControl();
}

void CCurrencyEditCtrl::Show(BOOL nNewStatus) 
{
	COleControl::ShowWindow(nNewStatus);
}

////
////        Devolve a posi��o (caractere) da string formatada que cont�m o
////    ponto f�sico (coordenada x) dado.
////

int CCurrencyEditCtrl::FisToLog(int PixelX)
{
    if(PixelX<m_DeslPrimChar)
        return 0;

    int NumFmtChar=strlen(m_FmtText);
    for(int i=0; i<NumFmtChar; i++)
    {
        if(m_DeslPrimChar+i*m_CharWidth<=PixelX &&
           PixelX<=m_DeslPrimChar+(i+1)*m_CharWidth)
        {
            return i;
        }
    }
    return NumFmtChar;
}   

////
////        Devolve a posi��o do buffer de edi��o (m_Buffer) que cont�m o
////    caractere digitado correspondente a um caractere na string formatada.
////        Se o caractere da string formatada for um caractere digitado a
////    posi��o correspondente do mesmo ser� devolvida se for um caractere de
////    formata��o ser� devolvido o caractere digitado mais pr�ximo e que fique
////    a direita do caractere de formata��o.
////
int CCurrencyEditCtrl::FmtPosToRealPos(int FmtPos)
{
    // pular os zeros da formata��o 000 se houver!!!
    int i=0;
    if(m_Exibir000)
    {
        if(m_Text.GetLength()==0)
            i=4;
        else if(m_Text.GetLength()==1)
            i=3;
        else if(m_Text.GetLength()==2)
            i=2;
    }

    int RealPos=0;
    for(; i<FmtPos; i++)
    {
        // � d�gito?
        if('0'<=m_FmtText[i] && m_FmtText[i]<='9')
            RealPos++;
    }
    return RealPos;
}   

BOOL CCurrencyEditCtrl::PreTranslateMessage(MSG* pMsg)
{
	HWND m_hParent = ::GetParent(m_hWnd);

	if (pMsg->message == WM_KEYDOWN)
	{
		if (pMsg->wParam == VK_LEFT || pMsg->wParam == VK_RIGHT || 
			pMsg->wParam == VK_UP    || pMsg->wParam == VK_DOWN )
		{
			::SendMessage(m_hParent, pMsg->message, pMsg->wParam, pMsg->lParam);
			SendMessage(pMsg->message, pMsg->wParam, pMsg->lParam);
			return TRUE;
		}
	}
	if (pMsg->message == WM_KEYUP)
	{
		if (pMsg->wParam == VK_LEFT || pMsg->wParam == VK_RIGHT || 
			pMsg->wParam == VK_UP   || pMsg->wParam == VK_DOWN )
		{
			::SendMessage(m_hParent, pMsg->message, pMsg->wParam, pMsg->lParam);
			SendMessage(pMsg->message, pMsg->wParam, pMsg->lParam);
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CCurrencyEditCtrl::GetLocked() 
{
	return m_Locked;
}

void CCurrencyEditCtrl::SetLocked(BOOL bNewValue) 
{
	m_Locked = bNewValue;

	SetModifiedFlag();
	InvalidateControl();
}

short CCurrencyEditCtrl::GetSelStart() 
{
	return m_SelStart;
}

void CCurrencyEditCtrl::SetSelStart(short nNewValue) 
{
	m_SelStart = nNewValue;
	m_SelBegin = m_SelStart;

	SetModifiedFlag();
	InvalidateControl();
}

short CCurrencyEditCtrl::GetSelLength() 
{
	return m_SelLength;
}

void CCurrencyEditCtrl::SetSelLength(short nNewValue) 
{
	if( nNewValue >= m_Text.GetLength() )
	{
		m_SelLength = m_Text.GetLength() - 1;
	}
	else if( nNewValue == 0 )
	{
		m_SelBegin = -1;
		m_SelLength = nNewValue;
	}
	else
	{
		m_SelLength = nNewValue;
	}

	m_SelEnd = m_SelBegin + m_SelLength;

	SetModifiedFlag();
	InvalidateControl();
}
