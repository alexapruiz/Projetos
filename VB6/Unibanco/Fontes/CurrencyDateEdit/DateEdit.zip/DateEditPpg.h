#if !defined(AFX_DATEEDITPPG_H__4A8E27D7_EACA_11D3_9FFC_00104BC8688C__INCLUDED_)
#define AFX_DATEEDITPPG_H__4A8E27D7_EACA_11D3_9FFC_00104BC8688C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// DateEditPpg.h : Declaration of the CDateEditPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CDateEditPropPage : See DateEditPpg.cpp.cpp for implementation.

class CDateEditPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CDateEditPropPage)
	DECLARE_OLECREATE_EX(CDateEditPropPage)

// Constructor
public:
	CDateEditPropPage();

// Dialog Data
	//{{AFX_DATA(CDateEditPropPage)
	enum { IDD = IDD_PROPPAGE_DATEEDIT };
	CString	m_Separator;
	CString	m_Text;
	long	m_MaxYear;
	long	m_MinYear;
	BOOL	m_Locked;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CDateEditPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATEEDITPPG_H__4A8E27D7_EACA_11D3_9FFC_00104BC8688C__INCLUDED)
