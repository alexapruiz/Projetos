// DateEditPpg.cpp : Implementation of the CDateEditPropPage property page class.

#include "stdafx.h"
#include "DateEdit.h"
#include "DateEditPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CDateEditPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CDateEditPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CDateEditPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CDateEditPropPage, "DATEEDIT.DateEditPropPage.1",
	0x4a8e27c8, 0xeaca, 0x11d3, 0x9f, 0xfc, 0, 0x10, 0x4b, 0xc8, 0x68, 0x8c)


/////////////////////////////////////////////////////////////////////////////
// CDateEditPropPage::CDateEditPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CDateEditPropPage

BOOL CDateEditPropPage::CDateEditPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_DATEEDIT_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CDateEditPropPage::CDateEditPropPage - Constructor

CDateEditPropPage::CDateEditPropPage() :
	COlePropertyPage(IDD, IDS_DATEEDIT_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CDateEditPropPage)
	m_Separator = _T("");
	m_Text = _T("");
	m_MaxYear = 0;
	m_MinYear = 0;
	m_Locked = FALSE;
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CDateEditPropPage::DoDataExchange - Moves data between page and properties

void CDateEditPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CDateEditPropPage)
	DDP_Text(pDX, IDC_EDIT_SEPARATOR, m_Separator, _T("Separator") );
	DDX_Text(pDX, IDC_EDIT_SEPARATOR, m_Separator);
	DDV_MaxChars(pDX, m_Separator, 1);
	DDP_Text(pDX, IDC_EDIT_TEXT, m_Text, _T("Text") );
	DDX_Text(pDX, IDC_EDIT_TEXT, m_Text);
	DDV_MaxChars(pDX, m_Text, 8);
	DDP_Text(pDX, IDC_EDIT_MAXYEAR, m_MaxYear, _T("MaxYear") );
	DDX_Text(pDX, IDC_EDIT_MAXYEAR, m_MaxYear);
	DDV_MinMaxLong(pDX, m_MaxYear, 0, 9999);
	DDP_Text(pDX, IDC_EDIT_MINYEAR, m_MinYear, _T("MinYear") );
	DDX_Text(pDX, IDC_EDIT_MINYEAR, m_MinYear);
	DDV_MinMaxLong(pDX, m_MinYear, 0, 9999);
	DDP_Check(pDX, IDC_CHECK_LOCKED, m_Locked, _T("Locked") );
	DDX_Check(pDX, IDC_CHECK_LOCKED, m_Locked);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CDateEditPropPage message handlers
