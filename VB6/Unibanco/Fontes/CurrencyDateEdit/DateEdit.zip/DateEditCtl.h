#if !defined(AFX_DATEEDITCTL_H__4A8E27D5_EACA_11D3_9FFC_00104BC8688C__INCLUDED_)
#define AFX_DATEEDITCTL_H__4A8E27D5_EACA_11D3_9FFC_00104BC8688C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// DateEditCtl.h : Declaration of the CDateEditCtrl ActiveX Control class.

const short vmes[12] = { 31, 28, 31, 30, 31, 30,
                                   31, 31, 30, 31, 30, 31 };


/////////////////////////////////////////////////////////////////////////////
// CDateEditCtrl : See DateEditCtl.cpp for implementation.

class CDateEditCtrl : public COleControl
{
	DECLARE_DYNCREATE(CDateEditCtrl)

// Constructor
public:
	CDateEditCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDateEditCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

	virtual BOOL PreTranslateMessage(MSG* pMsg);

// Implementation
protected:
	~CDateEditCtrl();

	DECLARE_OLECREATE_EX(CDateEditCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CDateEditCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CDateEditCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CDateEditCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CDateEditCtrl)
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnEnable(BOOL bEnable);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CDateEditCtrl)
	afx_msg BSTR GetSeparator();
	afx_msg void SetSeparator(LPCTSTR lpszNewValue);
	afx_msg BSTR GetMaskText();
	afx_msg BSTR GetInverseText();
	afx_msg long GetMinYear();
	afx_msg void SetMinYear(long nNewValue);
	afx_msg long GetMaxYear();
	afx_msg void SetMaxYear(long nNewValue);
	afx_msg BOOL GetLocked();
	afx_msg void SetLocked(BOOL bNewValue);
	afx_msg short GetSelStart();
	afx_msg void SetSelStart(short nNewValue);
	afx_msg short GetSelLength();
	afx_msg void SetSelLength(short nNewValue);
	afx_msg void SetSysDate();
	afx_msg OLE_COLOR GetBackColor();
	afx_msg void SetBackColor(OLE_COLOR nNewValue);
	afx_msg BSTR GetText();
	afx_msg void SetText(LPCTSTR lpszNewValue);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CDateEditCtrl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CDateEditCtrl)
	dispidSeparator = 1L,
	dispidMaskText = 2L,
	dispidInverseText = 3L,
	dispidMinYear = 4L,
	dispidMaxYear = 5L,
	dispidLocked = 6L,
	dispidSelStart = 7L,
	dispidSelLength = 8L,
	dispidSetSysDate = 9L,
	//}}AFX_DISP_ID
	};

private:
    //  int m_MaxNumCar : N�mero m�ximo de caracteres neste campo de edi��o.
    //                    Calculado baseado na largura da janela e no tamanho
    //                    do fonte.
    //
    //  int m_CarWidth : largura m�xima de um caractere no fonte selecionado.
    //  int m_CarHeight : altura m�xima de um caractere no fonte selecionado.
    //
    //  int m_EditPos : Posi��o do buffer sendo editada atualmente. Onde ser�
    //                  colocado o pr�ximo caractere digitado.
    //
    //  BOOL m_Insert : modo de edi��o ( Insert ou Overwrite )
    //
    int m_MaxNumChar;
    int m_CharWidth;
	int m_CharHeight;
    int m_EditPos;
	CString m_Text;
	CString m_MaskText;
    BOOL m_Insert;
    int m_IncrCaret;
    BOOL m_HasFocus;
	CString m_Separator;
	long m_MaxYear, m_MinYear;

    //
    //   int m_DeslPrimChar : posicao da tela onde sera desenhado o primeira char!
    //
    //   int m_Align : alinhamento do texto : 0=esquerda e 1=direita.
    //
    int m_DeslPrimChar;
    int m_Align;
	BOOL m_Locked;


    //
    // BOOL m_Selecting : indica se esta sendo selecionado texto.
    //
    // int m_SelBegin  : in�cio do bloco selecionado. Primeiro Caractere
    //                   (n�o de formata��o) de m_Buffer que faz
    //                   parte da faixa selecionada.
    //                   Se n�o houver faixa selecionada m_SelBegin fica com -1.
    //
    // int m_SelEnd    : fim do bloco selecionado. �ltimo Caractere
    //                   (n�o de formata��o) de m_Buffer que faz parte da
    //                   faixa selecionada.
    //
    // int m_FirstPixelX : indica o primeiro pixel clicado. Usado para saber
    //                     se houve um deslocamento consider�vel (3 4 pixel)
    //                     para iniciar a marca��o de faixa de texto.
    //
    BOOL m_Selecting;
    int m_SelBegin,
        m_SelEnd;
	short m_SelStart,
		  m_SelLength;
    int m_FirstPixelX;
    int m_PosBase;

    //
    //  char m_FmtText[MAX_NUM_CHAR_BUFFER] : texto formatado. Usado na sele��o
    //       de �reas de texto para mapear um caractere do texto formatado
    //       para o texto digitado.
    //
    char m_FmtText[MAX_NUM_CHAR_BUFFER];

	OLE_COLOR m_BackColor;
	CPen mPenGray, mPenLtGray, mPenWhite, mPenBlack;

    int FisToLog(int PixelX);
    int FmtPosToRealPos(int FmtPos);
	void Clear();
	void Show(BOOL nNewStatus);
    /* espera a string no formato ddmmaaaa */
 	BOOL ValidateDate( CString strDate );

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATEEDITCTL_H__4A8E27D5_EACA_11D3_9FFC_00104BC8688C__INCLUDED)
