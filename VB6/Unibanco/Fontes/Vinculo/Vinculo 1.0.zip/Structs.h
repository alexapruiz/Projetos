
#if !defined(STRUCTS_H)
#define STRUCTS_H

typedef struct
{
	long IdCapa;
	CString IdEnv_Mal;
	CString Agencia;
	CString Conta;
	CString Status;
	BOOL GerarAjuste;

} CAPA;

typedef struct
{
	long IdDocto;
	__int64 Valor;
	int TipoDocto,
	    Vinculo;
	CString TipoGenerico,
		    Leitura;
	BOOL Alcada,
		 DesprezarVinculo;
} DOCUMENTO;

#endif