// Vinculador.cpp: implementation of the CVinculador class.
//
//////////////////////////////////////////////////////////////////////

/*
  Data      Versao       Descricao
17/11/2000  2.1          Tratamento do Lancamento Interno (tipodocto = 41)
04/01/2001  2.2          Alcada para Cheque Compensado CP (6) e LI (41)
22/01/2001  2.2			 Verificar e enviar capas para Conferencia de Ag/Conta
02/03/2001  2.3          Alteracao na conexao sem usar ODBC
12/03/2001  2.4          Nao fazer Ajuste Contabil para LI (tipodocto = 41)
16/04/2001  2.5          Aceitar Cheque 230 (Bandeirante) como Cheque Ubb
06/06/2001  2.6          Nova Regra do Lan�amento Interno

*/

#include "stdafx.h"
#include "math.h"
#include "string.h"
#include "Vinculador.h"
#include "GetDataProc.h"
#include "GetValoresParametro.h"
#include "GetCapaVincular.h"
#include "GetDocumentos.h"
#include "GetAgContaDeposito.h"
#include "GetIdDoctoAjuste.h"
#include "GetDocOcorrencia.h"
#include "GetDocumentoTransmitido.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVinculador::CVinculador()
{
}

CVinculador::~CVinculador()
{

}

BOOL CVinculador::Init( void )
{
	char strServer[256];
	char strDatabase[256];
	char strFileName[256];
	CString strConnection;

	if( GetWindowsDirectory( strFileName, 255) <= 0 )
	{
		strcpy(m_MsgError, "Nao foi possivel obter o diretorio do Windows");
		m_iCodError = 501;
		return FALSE;
	}
	strcat(strFileName, "\\");
	strcat(strFileName, INI_FILE);

	if( GetPrivateProfileString( "Vinculo", "Servidor", "", strServer, 255, strFileName) <= 0 )
	{
		strcpy(m_MsgError, "Nao foi possivel obter o nome do Servidor do banco");
		m_iCodError = 502;
		return FALSE;
	}
	
	if( GetPrivateProfileString( "Vinculo", "DataBase", "", strDatabase, 255, INI_FILE ) <= 0 )
	{
		strcpy(m_MsgError, "Nao foi possivel obter o nome do Banco de Dados");
		m_iCodError = 503;
		return FALSE;
	}
	
	strConnection.Format( "driver={SQL Server};Server=%s;UID=i;PWD=i;Database=%s;provider=sqloledb",
						  strServer, strDatabase );
	try
	{
		m_oDB.OpenEx( LPCTSTR(strConnection), CDatabase::noOdbcDialog );
	}
	catch (CDBException *E)
	{
		//Armazena a informa��o sobre o erro
		strcpy(m_MsgError, LPCSTR(E->m_strError)); 
		strcat(m_MsgError, " (CVinculador.Init) ");
		m_iCodError= E->m_nRetCode;  

		E->Delete(); 
		return FALSE;		
	}

	m_pParametro = new CGetValoresParametro(&m_oDB);
	m_pCapa = new CGetCapaVincular(&m_oDB);
	m_pDoc = new CGetDocumentos(&m_oDB);
	m_pDep = new CGetAgContaDeposito(&m_oDB);
	m_pAjuste = new CGetIdDoctoAjuste(&m_oDB);

	m_iSleep = 20;
	memset(&m_Msg, '\0', sizeof(MSG));

	return TRUE; 

}

void CVinculador::Done( void )
{
	if( m_pParametro != NULL )
	{
		if ( m_pParametro->IsOpen() )
			m_pParametro->Close();
		delete m_pParametro;
	}
	
	if( m_pCapa != NULL )
	{
		if ( m_pCapa->IsOpen() )
			m_pCapa->Close();
		delete m_pCapa;
	}

	if( m_pDoc != NULL )
	{
		if ( m_pDoc->IsOpen() )
			m_pDoc->Close();
		delete m_pDoc;
	}

	if( m_pDep != NULL )
	{
		if ( m_pDep->IsOpen() )
			m_pDep->Close();
		delete m_pDep;
	}

	if( m_pAjuste != NULL )
	{
		if ( m_pAjuste->IsOpen() )
			m_pAjuste->Close();
		delete m_pAjuste;
	}

	m_oDB.Close(); 
	m_ArrayDoc.RemoveAll();

}

void CVinculador::GetLastErrorInfo(int& iCodError, char *lpszMsgError)
{
	iCodError = m_iCodError;
	strcpy(lpszMsgError, m_MsgError);
}

// retorna: -1 se erro; 0 se nao existe capa; 1 se existe capa
int CVinculador::ObtemCapa( void )
{
	CString strNumMalote;

	while( true )
	{
		try
		{
			if ( m_pCapa->IsOpen() )
				m_pCapa->Close();

			m_pCapa->m_DataProc = m_lDataProc;
			if( !m_pCapa->Open( CRecordset::snapshot, NULL ) )
			{
				//Armazena a informa��o sobre o erro
				strcpy(m_MsgError, "Erro na obten��o da Capa para Vincular. (CGetCapaVincular.Open)"); 
				m_iCodError= 100;  
				return -1;
			}
			else
			{
				if( m_pCapa->IsEOF() )
				{
					m_pCapa->Close();
					m_pCapa->m_DataProc = m_lDataProc;
					if( !m_pCapa->Open( CRecordset::snapshot, _T("{ Call VA_GetCapaVincular( ? ) }") ) )
					{
						//Armazena a informa��o sobre o erro
						strcpy(m_MsgError, "Erro na obten��o da Capa para Vincular. (CGetCapaVincular.Open)"); 
						m_iCodError= 100;  
						return -1;
					}
					else
					{
						if( m_pCapa->IsEOF() )
						{
							return 0;
						}
						else
						{
							// sai do while
							break;
						}
					}
				}
				else
				{
					// sai do while
					break;
				}
			}
		}
		catch (CDBException *E)
		{
			//Armazena a informa��o sobre o erro
			strcpy(m_MsgError, LPCSTR(E->m_strError)); 
			strcat(m_MsgError, " (CGetCapaVincular.Open) ");
			m_iCodError= E->m_nRetCode;  
			E->Delete(); 

			if( memcmp(m_MsgError, "Timeout expired", 15) != 0 )
			{
				return -1;		
			}
		}
	} // while

	m_Capa.IdCapa    = m_pCapa->m_IdCapa;
	m_Capa.IdEnv_Mal = m_pCapa->m_IdEnv_Mal;
	m_Capa.NovaRegra = FALSE;
	m_Capa.Diferenca = 0;

	if( m_Capa.IdEnv_Mal == "M" )
	{
		strNumMalote.Format("%011.11s", LPCTSTR(m_pCapa->m_NumMalote));
		m_Capa.Num_Malote = strNumMalote;
		m_Capa.Agencia = strNumMalote.Left(4);
		m_Capa.Conta   = strNumMalote.Right(7);

		if( strNumMalote.Left(1) == "9" )
			m_Capa.NovaRegra = TRUE;
	}
	else
	{
		m_Capa.Agencia = "";
		m_Capa.Conta   = "";
	}
	m_Capa.Status      = "";
	if( m_pCapa->m_Status == "9" )
	{
		m_Capa.GerarAjuste = TRUE;
	}
	else
	{
		m_Capa.GerarAjuste = FALSE;
	}

	m_pCapa->Close();
	return 1;
}

BOOL CVinculador::LeDataProc( void )
{
	CGetDataProc m_oGetDataProc(&m_oDB);

	try
	{
		if( !m_oGetDataProc.Open( CRecordset::snapshot, NULL ) )
		{
			//Armazena a informa��o sobre o erro
			strcpy(m_MsgError, "Erro na obten��o da Data de Processamento. (CGetDataProc.Open)"); 
			m_iCodError= 100;  
			return FALSE;
		}
		else
		{
			if( m_oGetDataProc.IsEOF() )
			{
				//Armazena a informa��o sobre o erro
				strcpy(m_MsgError, "Erro. N�o foi poss�vel obter a data do processamento. (CGetDataProc.Eof)"); 
				m_iCodError= 100;  
				return FALSE;
			}
			else
			{
				m_lDataProc = m_oGetDataProc.m_DataProc;
				//m_lDataProc = 20010627;
				//m_lDataProc = 20010626;
				m_iSleep    = m_oGetDataProc.m_Sleep;
				m_oGetDataProc.Close();
			}
		}
	}
	catch (CDBException *E)
	{
		//Armazena a informa��o sobre o erro
		strcpy(m_MsgError, LPCSTR(E->m_strError)); 
		strcat(m_MsgError, " (CGetDataProc.Open) ");
		m_iCodError= E->m_nRetCode;  

		E->Delete(); 
		return FALSE;		
	}
	return TRUE;
}

BOOL CVinculador::LeParametros( void )
{
	try
	{
		if ( m_pParametro->IsOpen() )
			m_pParametro->Close();

		m_pParametro->m_DataProc = m_lDataProc;
		if( !m_pParametro->Open( CRecordset::snapshot, NULL ) )
		{
			//Armazena a informa��o sobre o erro
			strcpy(m_MsgError, "Erro na obten��o dos Valores de Parametro. (CGetValoresParametro.Open)"); 
			m_iCodError= 100;  
			return FALSE;
		}
		else if( m_pParametro->IsEOF() )
		{
			//Armazena a informa��o sobre o erro
			strcpy(m_MsgError, "Erro na obten��o dos Valores de Parametro. (CGetValoresParametro.Eof)"); 
			m_iCodError= 100;  
			return FALSE;
		}
	}
	catch (CDBException *E)
	{
		//Armazena a informa��o sobre o erro
		strcpy(m_MsgError, LPCSTR(E->m_strError)); 
		strcat(m_MsgError, " (CGetValoresParametro.Open) ");
		m_iCodError= E->m_nRetCode;  

		E->Delete(); 
		return FALSE;		
	}
   	
	return TRUE; 
}

// retorna: -1 se erro; 0 se nao existe capa; 1 se existe capa
int CVinculador::ProcessaVinculo( void )
{
	int iCodRet;
	HANDLE hThread;
	BOOL bChangePriority;

	if( !LeDataProc() )
		return -1;

	iCodRet = ObtemCapa();
	if( iCodRet < 1 )
		return iCodRet;

	if( PossuiDocumentoTransmitido() )
	{
		// Gravar Status da Capa 
		if( !AtualizaStatusCapa() )
			return -1;
		else
			return 1;
	}

	RemoveAjustes();

	iCodRet = ObtemDocumentos();
	if( iCodRet < 0 )
		return iCodRet;
	
	if( iCodRet == 0 ) // Nao existem documentos na Capa ou
					   // Existem documentos para Conf. Ag/Conta
	{
		// Gravar Status da Capa 
		if( !AtualizaStatusCapa() )
			return -1;
		else
			return 1;
	}

	if( !LeParametros() )
		return -1;

	if( !VerificaSituacao() ) // Algum problema na capa
	{
		// Gravar Status da Capa 
		if( !AtualizaStatusCapa() )
			return -1;
		else
			return 1;
	}

	// Se houverem mais de 100 documentos no Envelpe / Malote
	// diminui a prioridade da Thread para o consumo de CPU
	// nao impactar o SQL Server
	if( m_ArrayDoc.GetUpperBound() >= 100 )
	{
		hThread = GetCurrentThread();
		bChangePriority = SetThreadPriority(hThread, THREAD_PRIORITY_BELOW_NORMAL);
	}

	if( VinculaLancamentoInterno() < 0 )
	{
		// Retorna a Thread a prioridade Normal
		if( bChangePriority )
			SetThreadPriority(hThread, THREAD_PRIORITY_NORMAL);
		return -1;
	}

	if( VinculaDeposito() < 0 )
	{
		// Retorna a Thread a prioridade Normal
		if( bChangePriority )
			SetThreadPriority(hThread, THREAD_PRIORITY_NORMAL);
		return -1;
	}

	if( m_Capa.IdEnv_Mal == "M") // Malote
	{
		if( VinculaDocumentoMalote() < 0 )
		{
			// Retorna a Thread a prioridade Normal
			if( bChangePriority )
				SetThreadPriority(hThread, THREAD_PRIORITY_NORMAL);
			return -1;
		}
	}
	else                         // Envelope
	{
		VinculaDocumentoEnvelope();
	}
	
	if( !AtualizaDocumentos() )
	{
		// Retorna a Thread a prioridade Normal
		if( bChangePriority )
			SetThreadPriority(hThread, THREAD_PRIORITY_NORMAL);
		return -1;
	}

	// Retorna a Thread a prioridade Normal
	if( bChangePriority )
		SetThreadPriority(hThread, THREAD_PRIORITY_NORMAL);

	if( !DespachaCapa() )
		return -1;

	return 1;
}

long CVinculador::GetSleep( void )
{
	return m_iSleep * 1000;
}

// retorna: -1 se erro; 0 se nao existe documentos; 1 se existe documentos
int CVinculador::ObtemDocumentos( void )
{
	DOCUMENTO Doc;
	CGetDocOcorrencia m_oDocOcorrencia(&m_oDB);

	m_ArrayDoc.RemoveAll();

	while( true )
	{
		try
		{
			if ( m_pDoc->IsOpen() )
				m_pDoc->Close();

			m_pDoc->m_DataProc = m_lDataProc;
			m_pDoc->m_IdCapa   = m_Capa.IdCapa;
			if( !m_pDoc->Open( CRecordset::snapshot, NULL ) )
			{
				//Armazena a informa��o sobre o erro
				strcpy(m_MsgError, "Erro na obten��o dos Documentos. (CGetDocumentos.Open)"); 
				m_iCodError= 100;  
				return -1;
			}
			else if( m_pDoc->IsEOF() )
			{
				// Capa sem documentos
				try
				{
					if( m_oDocOcorrencia.IsOpen() )
						m_oDocOcorrencia.Close();

					m_oDocOcorrencia.m_DataProc = m_lDataProc;
					m_oDocOcorrencia.m_IdCapa   = m_Capa.IdCapa;
					if( !m_oDocOcorrencia.Open( CRecordset::snapshot, NULL ) )
					{
						//Armazena a informa��o sobre o erro
						strcpy(m_MsgError, "Erro na obten��o na Qtde de Documentos com Ocorrencia. (CGetDocOcorrencia.Open)"); 
						m_iCodError= 100;  
						return -1;
					}
					if( m_oDocOcorrencia.m_Qtde > 0)
					{
						// So exitem documentos com ocorrencia na capa
						// Enviar para Transmissao
						m_Capa.Status = "R";
					}
					else
					{
						// Efetivamente nao existem documentos na capa
						// Enviar para Ilegivies
						m_Capa.Status = "5";
					}
					m_pDoc->Close();
					return 0;
				}
				catch(CDBException *E)
				{
					//Armazena a informa��o sobre o erro
					strcpy(m_MsgError, LPCSTR(E->m_strError)); 
					strcat(m_MsgError, " (CGetDocOcorrencia.Open) ");
					m_iCodError= E->m_nRetCode;  
					E->Delete(); 

					if( memcmp(m_MsgError, "Timeout expired", 15) != 0 )
					{
						return -1;		
					}
					else
						continue;
				}
			}
			break; // sai do while
		}
		catch (CDBException *E)
		{
			//Armazena a informa��o sobre o erro
			strcpy(m_MsgError, LPCSTR(E->m_strError)); 
			strcat(m_MsgError, " (CGetDocumentos.Open) ");
			m_iCodError= E->m_nRetCode;  
			E->Delete(); 

			if( memcmp(m_MsgError, "Timeout expired", 15) != 0 )
			{
				return -1;		
			}
		}
	} // while
   	
	while( !m_pDoc->IsEOF() )
	{
		Doc.IdDocto          = m_pDoc->m_IdDocto;
		Doc.TipoDocto        = m_pDoc->m_TipoDocto;
		Doc.Valor            = Converte(m_pDoc->m_Valor);
		Doc.Leitura          = m_pDoc->m_Leitura;
		Doc.Status			 = m_pDoc->m_Status;
		Doc.Vinculo          = 0;
		Doc.Alcada           = FALSE;
		Doc.DesprezarVinculo = FALSE;
		
		if( Doc.Status == "L" )
		{
			// Exitem documentos com status = "L" (para Conf. de Ag/Conta)
			// Enviar para Conferencia de Ag/Conta
			m_pDoc->Close();
			m_Capa.Status = "L";
			return 0;
		}

		switch(Doc.TipoDocto)
		{
			case 2:
			case 3:
			case 37:
				// DEPOSITO
				Doc.TipoGenerico = "DE";
				break;
			case 4:
			case 5:
			case 6:
			case 41:
				// ADCC ou CHEQUE DE PAGAMENTO
				Doc.TipoGenerico = "CP";
				break;
			case 7:
				// CHEQUE DE DEPOSITO
				Doc.TipoGenerico = "CD";
				break;
			case 32:
			case 34:
				// ACERTO DE CREDITO
				Doc.TipoGenerico = "AC";
				break;
			case 33:
			case 38:
				// ACERTO DE DEBITO
				Doc.TipoGenerico = "AD";
				break;
			case 39:
				// CAPA DE OCT
				Doc.TipoGenerico = "OC";
				break;
			default:
				// CONTAS
				Doc.TipoGenerico = "CO";
		}

		m_ArrayDoc.Add(Doc);
		m_pDoc->MoveNext();
	}
	
	m_pDoc->Close();
	return 1; 
}

BOOL CVinculador::VerificaSituacao( void )
{
	DOCUMENTO	Doc;
	int			i;
	int			j;
	int			k;
	int			iQtdDepositos = 0;
	BOOL		Deposito	  = FALSE;
	BOOL		Debito		  = FALSE;
	BOOL		Credito		  = FALSE;
	BOOL		NovaRegraLI   = FALSE;

	m_QtdChequePagto = 0;
	m_QtdContas      = 0;
	NovaRegraLI      = FALSE;

	if( m_Capa.IdEnv_Mal == "M" && !m_Capa.NovaRegra && m_lDataProc > m_pParametro->m_DataFinalRegraAntiga )
	{
        /**************************************
        ' * Enviando Capa para Ilegiveis      *
        ' *************************************/
		m_Capa.Status = "5";
		return FALSE; // Capa de malote com regra antiga
	}

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];

		if( Doc.TipoDocto == 0 || (Doc.TipoDocto != 39 && Doc.Valor <= 0) )
		{
            /**************************************
            ' * Documento n�o foi complementado   *
            ' * Enviando Capa para Ilegiveis      *
            ' *************************************/
			m_Capa.Status = "5";
			break;
		}
		else if( Doc.TipoDocto == 41 && m_Capa.IdEnv_Mal == "E" )
		{
            /**************************************
            ' * Nao pode haver LI em Envelope     *
            ' * Enviando Capa para Ilegiveis      *
            ' *************************************/
			m_Capa.Status = "5";
			break;
		}
		else if( Doc.TipoDocto == 39 )
		{
            /**********************
            ' * Capa possui OCT   *
            ' *********************/
			if( m_Capa.IdEnv_Mal != "M" )
			{
				/************************************************
				' * Nao pode haver capa de OCT em envelope      *
				' * Enviando Capa para Ilegiveis                *
				' ***********************************************/
				m_Capa.Status = "5";
				break;
			}
			else if( i == m_ArrayDoc.GetUpperBound() )
			{
				/*******************************************************
				' * OCT n�o pode ser o �ltimo Documento da Capa        *
				' * Enviando Capa para Ilegiveis                       *
				' ******************************************************/
				m_Capa.Status = "5";
				break;
			}
			else if( m_ArrayDoc[i+1].TipoDocto != 37 )
			{
                /********************************************************
                ' * N�o pode haver uma capa de OCT sem uma Ficha de OCT *
                ' * Enviando Capa para Ilegiveis                        *
                ' *******************************************************/
				m_Capa.Status = "5";
				break;
			}
		}
		else if( Doc.TipoGenerico == "DE" )
		{
			/***************************
			' * Capa possui Dep�sito   *
			' **************************/
			Deposito = TRUE;

			if( i == m_ArrayDoc.GetUpperBound() )
			{
				/*******************************************************
				' * Dep�sito n�o pode ser o �ltimo Documento da Capa   *
				' * Enviando Capa para Ilegiveis                       *
				' ******************************************************/
				m_Capa.Status = "5";
				break;
			}

			/****************************************************
			' * Verifica��o da nova regra do Lan�amento Interno *
			****************************************************/
			iQtdDepositos++;
			NovaRegraLI = TRUE; // Se alguma coisa n�o bater, setar como FALSE
			j = i + 1;

			while( j <= m_ArrayDoc.GetUpperBound() )
			{
				if( m_ArrayDoc[j].TipoGenerico == "DE" ||
					m_ArrayDoc[j].TipoGenerico == "OC" )
				{
					iQtdDepositos++;
					j++;
					continue;
				}
					/***************************************
					  O pr�ximo documento precisa ser um LI
					***************************************/
				else if ( m_ArrayDoc[j].TipoGenerico == "CP" && m_ArrayDoc[j].TipoDocto == 41 )
				{
					/******************************
					  N�o pode ter mais de um LI
					******************************/
					for ( k = j + 1; k <= m_ArrayDoc.GetUpperBound(); k++ )
					{
						if ( m_ArrayDoc[k].TipoGenerico == "CP" && m_ArrayDoc[k].TipoDocto == 41 )
						{
							m_Capa.Status = "5";
							NovaRegraLI   = FALSE;
							break;
						}
					}
					/*********************************
					  Verifica ent�o se s�o cobran�as
					*********************************/
					if (NovaRegraLI == TRUE)
					{
						for (j = j + 1 ; j <= m_ArrayDoc.GetUpperBound(); j++)
						{
							if ( m_ArrayDoc[j].TipoGenerico != "CO" )
							{
								m_Capa.Status = "5";
								NovaRegraLI   = FALSE;
								break;
							}
						}
					}
				}
				else
				{
					NovaRegraLI = FALSE;
					break;
				}
				j++;
			}

			/*****************************************
			  Fim da nova regra do Lan�amento Interno
			*****************************************/

			if( m_ArrayDoc[i+1].TipoGenerico == "DE" && NovaRegraLI == FALSE)
			{
                /****************************************
                ' * N�o pode haver 2 Dep�sitos seguidos *
                ' * Enviando Capa para Ilegiveis        *
                ' ***************************************/
				m_Capa.Status = "5";
				break;
			}
			else if( Doc.TipoDocto == 37 )
			{
				/***********************************
				' * Se eh uma OCT                  *
				' **********************************/
				if( m_Capa.IdEnv_Mal != "M" )
				{
					/************************************************
					' * Nao pode haver OCT em envelope              *
					' * Enviando Capa para Ilegiveis                *
					' ***********************************************/
					m_Capa.Status = "5";
					break;
				}
				else if( i == 0 || m_ArrayDoc[i-1].TipoDocto != 39)
				{
                    /********************************************************
                    ' * N�o pode haver uma Ficha de OCT sem uma Capa de OCT *
					' * Enviando Capa para Ilegiveis                        *
					' *******************************************************/
					m_Capa.Status = "5";
					break;
				}
				else if( m_ArrayDoc[i+1].TipoDocto == 37 )
				{
					/****************************************
					' * N�o pode haver 2 Octs seguidas      *
					' * Enviando Capa para Ilegiveis        *
					' ***************************************/
					m_Capa.Status = "5";
					break;
				}
			}
		}
		else if( Deposito )
		{
            /************************************
            ' * Documento depois de um Dep�sito *
			'									*
			' * 11-06-2001						*
			' * N�o pode estar dentro da nova   *
			' * regra do Lan�amento Interno     *
            ' ***********************************/
			if( (Doc.TipoGenerico == "CO" || Doc.TipoDocto == 4) && NovaRegraLI == FALSE)
			{
                /**************************************
                ' * Documento fora de Ordem           *
                ' * Enviando Capa para Ilegiveis      *
                ' *************************************/
				m_Capa.Status = "5";
				break;
			}
			else if( Doc.TipoGenerico != "AD" && Doc.TipoGenerico != "AC" &&
				     Doc.TipoGenerico != "OC" && Doc.TipoDocto != 41 && 
					 NovaRegraLI == FALSE)
			{
                /**************************************************
                ' * Transformando Documento em Cheque de Deposito *
                ' *************************************************/
				m_ArrayDoc[i].TipoDocto = 7;
				m_ArrayDoc[i].Alcada = FALSE;
				m_ArrayDoc[i].TipoGenerico = "CD";
			}
		}
		// Verifica Alcada
		if( m_Capa.IdEnv_Mal == "M" ) // Malote
		{
			// Se CH. UBB > ValorAlcada
			if( (m_ArrayDoc[i].TipoDocto == 5 || m_ArrayDoc[i].TipoDocto == 4) && 
				m_ArrayDoc[i].Valor >= Converte(m_pParametro->m_ValorAlcada_Mal) )
			{
				m_ArrayDoc[i].Alcada = TRUE;
			}
			// Se Dep. CC ou Poup > ValorAlcadaDep
			else if( (m_ArrayDoc[i].TipoDocto == 2 || m_ArrayDoc[i].TipoDocto == 3 ) && 
					  m_ArrayDoc[i].Valor >= Converte(m_pParametro->m_ValorAlcadaDep_Mal) )
			{
				m_ArrayDoc[i].Alcada = TRUE;
			}
			// Se Ch. Compensado (CP) ou LI > ValorAlcadaOutros
			else if( (m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 41 ) && 
					  m_ArrayDoc[i].Valor >= Converte(m_pParametro->m_ValorAlcadaOutros_Mal) )
			{
				m_ArrayDoc[i].Alcada = TRUE;
			}
		}
		else                          // Envelope
		{
			// Se CH. UBB > ValorAlcada
			if( (m_ArrayDoc[i].TipoDocto == 5  || m_ArrayDoc[i].TipoDocto == 4) && 
				m_ArrayDoc[i].Valor >= Converte(m_pParametro->m_ValorAlcada_Env) )
			{
				m_ArrayDoc[i].Alcada = TRUE;
			}
			// Se Dep. CC ou Poup > ValorAlcadaDep
			else if( (m_ArrayDoc[i].TipoDocto == 2 || m_ArrayDoc[i].TipoDocto == 3 ) && 
					  m_ArrayDoc[i].Valor >= Converte(m_pParametro->m_ValorAlcadaDep_Env) )
			{
				m_ArrayDoc[i].Alcada = TRUE;
			}
			// Se Ch. Compensado (CP) ou LI > ValorAlcadaOutros
			else if( (m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 41 ) && 
					  m_ArrayDoc[i].Valor >= Converte(m_pParametro->m_ValorAlcadaOutros_Env) )
			{
				m_ArrayDoc[i].Alcada = TRUE;
			}
		}

		if( (Doc.TipoDocto >= 4 && Doc.TipoDocto <= 7) || Doc.TipoDocto == 41 )
		{
			Debito = TRUE;
		}
		else if( Doc.TipoDocto != 39 )
		{
			Credito = TRUE;
		}

		if( Doc.TipoGenerico == "CP" )
		{
			m_QtdChequePagto++;
		}
		else if( Doc.TipoGenerico == "CO" )
		{
			m_QtdContas++;
		}

	}
	if( m_Capa.Status == "" && (!Debito || !Credito) )
	{
		/********************************************************
		' * Deve haver pelo menos um Debito e pelo menos um     *
		' * Credito                                             *
		' * Enviando Capa para Ilegiveis                        *
		' *******************************************************/
		m_Capa.Status = "5";
	}

	if( !m_Capa.Status.IsEmpty() )
		return FALSE; // Capa com problemas
	else
		return TRUE; // Capa Ok
}

BOOL CVinculador::AtualizaStatusCapa( void )
{
	CString strSql;

	strSql.Format("Execute VA_AtualizaStatusCapa %ld, %ld, '%s', %.2f", 
				   m_lDataProc, m_Capa.IdCapa, LPCTSTR(m_Capa.Status), ((double)abs(m_Capa.Diferenca) / 100));

	try
	{
		m_oDB.ExecuteSQL(LPCTSTR(strSql));
	}
	catch (CDBException *E)
	{
		//Armazena a informa��o sobre o erro
		strcpy(m_MsgError, LPCSTR(E->m_strError)); 
		strcat(m_MsgError, " (AtualizarStatusCapa) ");
		m_iCodError= E->m_nRetCode;  

		E->Delete(); 
		return FALSE;		
	}

	if( m_Capa.Status == "4" )
	{
		InsereLog( 110 );
	}
	else if( m_Capa.Status == "5" )
	{
		InsereLog( 111 );
	}
	else if( m_Capa.Status == "6" )
	{
		InsereLog( 112 );
	}
	else if( m_Capa.Status == "7" )
	{
		InsereLog( 113 );
	}
	else if( m_Capa.Status == "R" )
	{
		InsereLog( 114 );
	}
	else if( m_Capa.Status == "V" )
	{
		InsereLog( 115 );
	}

	return TRUE;
}

// retorna: -1 se erro; 1 se Ok
int CVinculador::VinculaLancamentoInterno( void )
{

	DOCUMENTO	Doc, Ajuste;
	int			i, j, IndiceDeposito;
	long		lVinculo, IdDocto;
	__int64		ValorAjusteContabil, ValorLI, SomaConta, SomaDeposito, Diferenca;

	i			   = 0;
	IndiceDeposito = 0;
	while( i <= m_ArrayDoc.GetUpperBound() )
	{
		Doc = m_ArrayDoc[i];
		if (Doc.TipoGenerico == "CP" && Doc.TipoDocto == 41 && i > 0)
		{
			lVinculo = Doc.IdDocto;
			ValorLI = Doc.Valor;
			SomaConta = 0;
			SomaDeposito = 0;
			/****************************
			  Soma valores dos Depositos
			****************************/
			j = i - 1;
			if( m_ArrayDoc[j].TipoGenerico == "DE" )
			{
				while( 
						(j >= 0) && 
						(m_ArrayDoc[j].TipoGenerico == "DE" ||
					     m_ArrayDoc[j].TipoGenerico == "OC")
					 )
				{
					SomaDeposito += m_ArrayDoc[j].Valor;

					if( j % 100 == 0 )
					{
						PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
					}
					IndiceDeposito = j;
					j--;
				}
			}
			/**********************************************
			  Se n�o for deposito, n�o est� dentro da regra
			**********************************************/
			else
				return 1;

			/*************************
			  Soma valores das contas
			*************************/
			j = i + 1;
			if( j <= m_ArrayDoc.GetUpperBound() && m_ArrayDoc[j].TipoGenerico == "CO" )
			{
				while( j <= m_ArrayDoc.GetUpperBound() )
				{
					if( m_ArrayDoc[j].TipoGenerico == "CO" )
						SomaConta += m_ArrayDoc[j].Valor;
					else
						return -1;

					if( j % 100 == 0 )
					{
						PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
					}
					j++;
				}
			}
			/**********************************************
			  Se n�o for conta, n�o est� dentro da regra
			**********************************************/
			//else
			//	return 1;

			if (lVinculo == 0)
				return -1;

			Diferenca = ValorLI - (SomaConta + SomaDeposito);

			/**********************************************
			  Se diferenca das contas e Lan�amento Interno
			  forem menor do que est� na tabela parametro
			  ValorAjusteContabil, gerar ajuste
			**********************************************/
			if ( (abs(Diferenca) > 0) && 
				 (m_Capa.GerarAjuste == TRUE))
			{
				//(abs(Diferenca) <= Converte(m_pParametro->m_ValorAjusteContabil)) &&

				ValorAjusteContabil = Converte(m_pParametro->m_ValorAjusteContabil);
				if( !m_Capa.NovaRegra )
				{
					//ValorAjusteContabil = Converte(m_pParametro->m_ValorAjusteAuto_Mal);
					ValorAjusteContabil = Converte(m_pParametro->m_LimiteMaxDifLancto_Mal);
				}

				if( abs(Diferenca) <= ValorAjusteContabil )
				{
					if( !InsereAjuste( ( Diferenca < 0 ? 43 : 42),
										0, "0", abs(Diferenca), IdDocto ))
					{
						return -1;
					}

					Ajuste.Alcada = FALSE;
					Ajuste.DesprezarVinculo = FALSE;
					Ajuste.IdDocto = IdDocto;
					Ajuste.TipoDocto = (Diferenca < 0 ? 43 : 42);
					Ajuste.TipoGenerico = (Diferenca < 0 ? "AD" : "AC");
					Ajuste.Valor = abs(Diferenca);
					Ajuste.Vinculo = 0;

					m_ArrayDoc.InsertAt(i+1, Ajuste, 1);
				}
			}

			/*******************************
			  Pega apartir do deposito que 
			  fora somado anteriormente
			*******************************/
			if( (abs(Diferenca) == 0 ) ||
				(abs(Diferenca) != 0 && m_Capa.GerarAjuste == TRUE && 
				(abs(Diferenca) <= ValorAjusteContabil))
			  )
			{
				for ( j = IndiceDeposito; j <= m_ArrayDoc.GetUpperBound(); j++)
				{

					m_ArrayDoc[j].Vinculo = lVinculo;

					if( j % 100 == 0 )
					{
						PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
					}
				}
			}
		}
		i++;
	}
	return 1;
}

// retorna: -1 se erro; 1 se Ok
int CVinculador::VinculaDeposito( void )
{
	DOCUMENTO Doc       , Ajuste;
	int       i         , j;
	long      lVinculo  , IdDocto;
	__int64   SomaCheque, SomaDeposito, Diferenca;
	int       Agencia;
	CString   Conta;


	/*****************************
	  N�o faz a vincula deposito 
	  se capa esta na Nova Regra
	  do Lan�amento Interno
	*****************************/
	if( NovaRegraLancamentoInterno() )
		return 1;

	i = 0;
	while( i <= m_ArrayDoc.GetUpperBound() )
	{
		Doc = m_ArrayDoc[i];

		lVinculo = 0;

		if( Doc.TipoGenerico == "DE" && Doc.Vinculo == 0 )
		{

			SomaDeposito = Doc.Valor;
			SomaCheque = 0;

			lVinculo = Doc.IdDocto;

			for( j = i + 1; j<= m_ArrayDoc.GetUpperBound(); j++ )
			{
				if( m_ArrayDoc[j].TipoGenerico == "CD" ||
					m_ArrayDoc[j].TipoDocto == 41 ) // LI
				{
					SomaCheque += m_ArrayDoc[j].Valor;
				}
				else
				{
					break;
				}
				if( j % 100 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}
			}
			Diferenca = SomaCheque - SomaDeposito;
			if( abs(Diferenca) > 0 )
			{
				if( !m_Capa.GerarAjuste )
				{
					i++;
					continue;
				}

				// Gerar Ajuste Debito / Credito
				if( !ObtemAgContaDeposito( Doc.IdDocto, Doc.TipoDocto, Agencia, Conta ) )
				{
					i++;
					continue;
				}
				if( !InsereAjuste( (SomaCheque > SomaDeposito ? 32 : 33), Agencia, Conta, abs(Diferenca), IdDocto) )
				{
					i++;
					continue;
				}
				Ajuste.Alcada = FALSE;
				Ajuste.DesprezarVinculo = FALSE;
				Ajuste.IdDocto = IdDocto;
				Ajuste.TipoDocto = (SomaCheque > SomaDeposito ? 32 : 33);
				Ajuste.TipoGenerico = (SomaCheque > SomaDeposito ? "AC" : "AD");
				Ajuste.Valor = abs(Diferenca);
				Ajuste.Vinculo = 0;
				m_ArrayDoc.InsertAt(i+1, Ajuste, 1);
			}
			// Se Oct entao vincular tambem a Capa
			if( Doc.TipoDocto == 37 )
			{
				m_ArrayDoc[i-1].Vinculo   = lVinculo;
			}

			m_ArrayDoc[i].Vinculo = lVinculo;

			// Vincula todos os cheques e ajustes ao deposito/oct
			for( j = i + 1; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				if( m_ArrayDoc[j].TipoGenerico == "CD" ||
					m_ArrayDoc[j].TipoDocto == 32 ||
					m_ArrayDoc[j].TipoDocto == 33 ||
					m_ArrayDoc[j].TipoDocto == 41 )// LI 
				{
					m_ArrayDoc[j].Vinculo   = lVinculo;
				}
				else
				{
					break;
				}
				if( j % 100 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}
			}
		}
		i++;
	}
	return 1;
}


BOOL CVinculador::ObtemAgContaDeposito( long IdDocto, long TipoDocto, int &Ag, CString &Cta )
{
	if ( m_pDep->IsOpen() )
		m_pDep->Close();

	m_pDep->m_DataProc  = m_lDataProc;
	m_pDep->m_IdDocto   = IdDocto;
	m_pDep->m_TipoDocto = TipoDocto;
	try
	{
		if( !m_pDep->Open( CRecordset::snapshot, NULL ) )
		{
			//Armazena a informa��o sobre o erro
			strcpy(m_MsgError, "Erro na obten��o da Ag. e Conta do Deposito. (CGetAgContaDeposito.Open)"); 
			m_iCodError= 100;  
			return FALSE;
		}
		else if( m_pDep->IsEOF() )
		{
			//Armazena a informa��o sobre o erro
			strcpy(m_MsgError, "Erro na obten��o da Ag. e Conta do Deposito. (CGetAgContaDeposito.Eof)"); 
			m_iCodError= 100;  
			return FALSE;
		}
	}
	catch (CDBException *E)
	{
		//Armazena a informa��o sobre o erro
		strcpy(m_MsgError, LPCSTR(E->m_strError)); 
		strcat(m_MsgError, " (AtualizarStatusCapa) ");
		m_iCodError= E->m_nRetCode;  

		E->Delete(); 
		return FALSE;		
	}

	Ag  = m_pDep->m_Agencia;
	Cta = m_pDep->m_Conta;

	m_pDep->Close();
	return TRUE;

}

BOOL CVinculador::InsereAjuste( int Tipo, int Ag, CString Cta, __int64 Valor, long &IdDocto )
{
	CString strSql;

	strSql.Format("Execute VA_InsereAjuste %ld, %ld, %d, %d, %s, %.2f",
				  m_lDataProc, m_Capa.IdCapa, Tipo, Ag, LPCTSTR(Cta), ((double)Valor / 100));

	try
	{
		m_oDB.ExecuteSQL(LPCTSTR(strSql));
	}
	catch (CDBException *E)
	{
		//Armazena a informa��o sobre o erro
		strcpy(m_MsgError, LPCSTR(E->m_strError)); 
		strcat(m_MsgError, " (InsereAjuste) ");
		m_iCodError= E->m_nRetCode;  

		E->Delete(); 
		return FALSE;		
	}

	try
	{
		m_pAjuste->m_DataProc  = m_lDataProc;
		m_pAjuste->m_IdCapa    = m_Capa.IdCapa;
		m_pAjuste->m_TipoDocto = Tipo;
		m_pAjuste->m_Valor     = ((double)Valor / 100);
		if( !m_pAjuste->Open( CRecordset::snapshot, NULL ) )
		{
			//Armazena a informa��o sobre o erro
			strcpy(m_MsgError, "Erro na obten��o do IdDocto do Ajuste. (CGetIdDoctoAjuste.Open)"); 
			m_iCodError= 100;  
			return FALSE;
		}
		else
		{
			if( m_pAjuste->IsEOF() )
			{
				//Armazena a informa��o sobre o erro
				strcpy(m_MsgError, "Erro na obten��o do IdDocto do Ajuste. (CGetIdDoctoAjuste.Eof)"); 
				m_iCodError= 100;  
				return FALSE;
			}
		}
	}
	catch (CDBException *E)
	{
		//Armazena a informa��o sobre o erro
		strcpy(m_MsgError, LPCSTR(E->m_strError)); 
		strcat(m_MsgError, " (InsereAjuste) ");
		m_iCodError= E->m_nRetCode;  

		E->Delete(); 
		return FALSE;		
	}

	IdDocto = m_pAjuste->m_IdDocto;
	m_pAjuste->Close();

	return TRUE;
}

// retorna: -1 se erro; 0 se nao vinculou; 1 se vinculou
int CVinculador::VinculaDocumentoMalote( void )
{
	if( m_Capa.NovaRegra )
		return VinculaDocumentoMaloteRegraNova();
	else
		return VinculaDocumentoMaloteRegraAntiga();
}

// retorna: -1 se erro; 0 se nao vinculou; 1 se vinculou
int CVinculador::VinculaDocumentoMaloteRegraNova( void )
{
	DOCUMENTO Doc, DocAux, Ajuste;
	int i, j, iQtdCheques, iQtdContas;
	int iQtdSemVinculo, iQtdADCC, iQtdLI, iQtdChPagto, iQtdChTerc;
	long iVinculo, IdDocto;
	__int64 ValorVinculo, Diferenca, ValorCheques, ValorContas;
	int iConta, iCheque;
	int iInicio, iDesprezar;
	CArray<int, int> aIndConta;
	CArray<int, int> aIndCheque;

	/* Comentario do Vagner:
	   Como a nova regra do Malote e quase tao restritiva quanto a
	   do Envelope, este algoritmo foi uma adapta��o do vinculo do
	   Envelope. Porem foi adicionado a ele a possibilidade de vincular
	   N cheques a 1 conta e N cheques a N contas, desde que os cheques
	   sejam todos do unibanco. Alem disso nao e permitido fazer ajustes
	   caso o vinculo envolva mais de um cheque.
	*/

	/*****************************************
    ' * Marcar para Desprezar para o V�nculo *
    ' * Os Cheques com o mesmo Valor         *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		iQtdCheques = 0;
		iQtdContas  = 0;

		Doc = m_ArrayDoc[i];
		
		if( Doc.DesprezarVinculo == FALSE && Doc.Vinculo == 0 && 
			Doc.TipoDocto > 3 && Doc.TipoDocto <= 6 )
		{
            /****************************
            ' * Cheque/ADCC sem V�nculo *
            ' ***************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.Vinculo == 0 && DocAux.Valor == Doc.Valor )
				{
					if( DocAux.TipoDocto > 3 && DocAux.TipoDocto <= 6 )
					{
                        /*******************************
                        ' * Cheque/ADCC no Mesmo Valor *
                        ' ******************************/
						iQtdCheques++;
					}
					else if( DocAux.TipoGenerico == "CO" )
					{
                        /*************************
                        ' * Conta no mesmo Valor *
                        ' ************************/
						iQtdContas++;
					}
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}

		if( iQtdContas > 1 && m_QtdChequePagto > 1 )
		{
            /*************************************************
            ' * Desprezar para o V�nculo Autom�tico          *
            ' ************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdContas > 1 && iQtdCheques > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdCheques > 1 && m_QtdContas > 1 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdCheques > 1 && iQtdContas > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}

		if( m_ArrayDoc[i].DesprezarVinculo )
		{
            /*****************************************
            ' * Marcar para Desprezar para o V�nculo *
            ' * Todos que tenham o mesmo valor       *
            ' ****************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				if( Doc.Valor == m_ArrayDoc[j].Valor )
					m_ArrayDoc[j].DesprezarVinculo = TRUE;
			}
		}
	}

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		iQtdContas     = 0;
		iQtdCheques    = 0;

		Doc = m_ArrayDoc[i];
		if( Doc.DesprezarVinculo == FALSE && Doc.Vinculo == 0 && 
			Doc.TipoGenerico == "CO" )
		{
            /***********************
            ' * Cheque sem V�nculo *
            ' **********************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.Vinculo == 0 && DocAux.Valor == Doc.Valor )
				{
					if( DocAux.TipoDocto > 3 && DocAux.TipoDocto <= 6 )
						iQtdCheques++;
					else if( DocAux.TipoGenerico == "CO" )
						iQtdContas++;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}


		if( iQtdCheques > 1 && m_QtdContas > 1 )
		{
            /*************************************************
            ' * Desprezar para o V�nculo Autom�tico          *
            ' ************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdCheques > 1 && iQtdContas > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdContas > 1 && m_QtdChequePagto > 1 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdContas > 1 && iQtdCheques > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}

		if( m_ArrayDoc[i].DesprezarVinculo )
		{
            /*****************************************
            ' * Marcar para Desprezar para o V�nculo *
            ' * Todos que tenham o mesmo valor       *
            ' ****************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				if( Doc.Valor == m_ArrayDoc[j].Valor )
					m_ArrayDoc[j].DesprezarVinculo = TRUE;
			}
		}
		
	}

    /****************************************
    ' * Primeira Fase do Vinculo            *
    ' * Vinculando Um Cheque para Uma Conta *
    ' ***************************************/

	/* Comentario do Vagner:
	   Nesta fase, se o Cheque de Pagamento for do Unibanco
	   pode-se vincula-lo a qualquer Cobranca/Arrecadacao.
	   Se o Cheque de Pagamento nao for do Unibanco
	   somente vincula-o se a Cobranca for diferente
	   de "Titulos Terceiros Sem CB" (12) e diferente de
	   "Cobranca Terceiros" (31)
	*/

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CP" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /**********************************************
            ' * Cheque, LI ou  ADCC a Verificar o Vinculo *
            ' *********************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.TipoGenerico == "CO" && 
					DocAux.Vinculo == 0 && 
					!DocAux.DesprezarVinculo &&
					Doc.Valor == DocAux.Valor )
				{
					if( (Doc.TipoDocto == 6 && DocAux.TipoDocto != 12 &&
						 DocAux.TipoDocto != 31) || Doc.TipoDocto == 5 ||
						 Doc.TipoDocto == 4 || Doc.TipoDocto == 41 )
					{
						/**********************************
						' * Vinculando Conta com o Cheque *
						' *********************************/
						m_ArrayDoc[i].Vinculo  = Doc.IdDocto;
						m_ArrayDoc[j].Vinculo  = Doc.IdDocto;
						/**************************************
						' * Corrige o tipodocumento do cheque *
						' *************************************/
						if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
						{
							if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230") )
							{
								m_ArrayDoc[i].TipoDocto = 5;
								if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
								{
									m_ArrayDoc[i].Alcada = TRUE;
								}
								else
								{
									m_ArrayDoc[i].Alcada = FALSE;
								}
							}
							else
							{
								m_ArrayDoc[i].TipoDocto = 6;
								if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
								{
									m_ArrayDoc[i].Alcada = TRUE;
								}
								else
								{
									m_ArrayDoc[i].Alcada = FALSE;
								}
							}
						}
						break;
					}
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /*********************************************
    ' * Verificando a Qtde de Contas no Malote   *
    ' * A Serem Vinculadas                       *
    ' *******************************************/
    iQtdContas = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CO" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdContas++;
	}

	if( iQtdContas == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

	/* Comentario do Vagner:
	   Nesta segunda fase o algoritmo tenta vincular um cheque com
	   uma combinacao das contas, esta combinacao comeca com n, depois
	   tenta n-1, n-2, ...
	   Porem ele so testa combinacoes com documentos adjacentes, 
	   ele nao verifica todas as combinacoes possiveis.
	*/

	/* Comentario do Vagner:
	   Nesta fase, se, e somente se, o Cheque de Pagamento for 
	   do Unibanco pode-se vincula-lo a qualquer Cobranca/Arrecadacao.
	*/

    /*****************************************
    ' * Segunda Fase do Vinculo              *
    ' * Vinculando Um Cheque a v�rias Contas *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto == 4 || Doc.TipoDocto == 5 || Doc.TipoDocto == 41) && 
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /*********************************************
            ' * Cheque, LI ou ADCC a Verificar o Vinculo *
            ' ********************************************/
			iInicio    = 1;
			iDesprezar = 1;
			while( iInicio <= iQtdContas )
			{
				ValorVinculo = 0;
				iConta       = 0;

				aIndConta.RemoveAll();
				for( j = 0; j < iQtdContas; j++ )
					aIndConta.Add(-1);

				for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
				{
					DocAux = m_ArrayDoc[j];
					if( DocAux.TipoGenerico == "CO" && 
						DocAux.Vinculo == 0 && 
						!DocAux.DesprezarVinculo )
					{
						iConta++;
						if( iConta == iInicio || iConta > iDesprezar )
						{
							ValorVinculo += DocAux.Valor;
							aIndConta[iConta-1] = j;
							if( ValorVinculo >= Doc.Valor )
								break;
						}
					}
				}
				if( iInicio % 50 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}

				/**********************************************
				 * Verifica se o Valor da Combinacao bate com *
				 * o valor do cheque, entao vincula           *
				 **********************************************/
				if( ValorVinculo == Doc.Valor )
				{
					m_ArrayDoc[i].Vinculo = Doc.IdDocto;
					/**************************************
					' * Corrige o tipodocumento do cheque *
					' *************************************/
					if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
					{
						if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230") )
						{
							m_ArrayDoc[i].TipoDocto = 5;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
						else
						{
							m_ArrayDoc[i].TipoDocto = 6;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
					}

					for( j = 0; j < iQtdContas; j++ )
					{
						if( aIndConta[j] >= 0 )
						{
							m_ArrayDoc[aIndConta[j]].Vinculo = Doc.IdDocto;
						}
					}
					break;
				}

				iDesprezar++;
				if( iDesprezar >= iQtdContas )
				{
					iInicio++;
					iDesprezar = iInicio;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /********************************************
    ' * Verificando a Qtde de Cheques no Malote *
    ' * A Serem Vinculados                      *
    ' *******************************************/
    iQtdCheques = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto >= 4 && Doc.TipoDocto < 7 || Doc.TipoDocto == 41) &&
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdCheques++;
	}

	if( iQtdCheques == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

	/* Comentario do Vagner:
	   Nesta terceira fase o algoritmo tenta vincular uma conta com
	   uma combinacao dos cheques, esta combinacao comeca com n, depois
	   tenta n-1, n-2, ...
	   Porem ele so testa combinacoes com documentos adjacentes, 
	   ele nao verifica todas as combinacoes possiveis.
	*/

	/* Comentario do Vagner:
	   Nesta fase, se, e somente se, todos os Cheques de Pagamento forem 
	   do Unibanco pode-se vincula-los a qualquer Cobranca/Arrecadacao.
	*/

    /*****************************************
    ' * Terceira Fase do Vinculo              *
    ' * Vinculando Uma Conta a v�rios Cheques *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CO" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /********************************
            ' * Conta a Verificar o Vinculo *
            ' *******************************/
			iInicio    = 1;
			iDesprezar = 1;
			while( iInicio <= iQtdCheques )
			{
				ValorVinculo = 0;
				iCheque      = 0;
				iQtdChPagto  = 0;
				iQtdADCC     = 0;
				iQtdLI       = 0;

				aIndCheque.RemoveAll();
				for( j = 0; j < iQtdCheques; j++ )
					aIndCheque.Add(-1);

				for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
				{
					DocAux = m_ArrayDoc[j];
					if( (DocAux.TipoDocto == 4 || DocAux.TipoDocto == 5 || 
						 DocAux.TipoDocto == 41 ) && DocAux.Vinculo == 0 && 
						!DocAux.DesprezarVinculo )
					{
						iCheque++;
						if( iCheque == iInicio || iCheque > iDesprezar )
						{
							if( DocAux.TipoDocto == 4 )
								iQtdADCC++;
							else if( DocAux.TipoDocto == 5 )
								iQtdChPagto++;
							else if( DocAux.TipoDocto == 41 )
								iQtdLI++;
							ValorVinculo += DocAux.Valor;
							aIndCheque[iCheque-1] = j;
							if( ValorVinculo >= Doc.Valor )
								break;
						}
					}
				}
				if( iInicio % 50 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}

				/**********************************************
				 * Verifica se o Valor da Combinacao bate com *
				 * o valor da conta, entao vincula            *
				 **********************************************/
				if( ValorVinculo == Doc.Valor )
				{
					/* Nao pode haver cheque vinculado com ADCC */
					if( iQtdChPagto == 0 || iQtdADCC == 0 )
					{
						m_ArrayDoc[i].Vinculo = Doc.IdDocto;
						for( j = 0; j < iQtdCheques; j++ )
						{
							if( aIndCheque[j] >= 0 )
							{
								m_ArrayDoc[aIndCheque[j]].Vinculo = Doc.IdDocto;
							}
						}
						break;
					}
				}

				iDesprezar++;
				if( iDesprezar >= iQtdCheques )
				{
					iInicio++;
					iDesprezar = iInicio;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /**********************************************
    ' * Verificando a Qtde de Cheques no Malote   *
    ' * A Serem Vinculados                        *
    ' ********************************************/
    iQtdCheques = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto >= 4 && Doc.TipoDocto < 7 || Doc.TipoDocto == 41) &&
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdCheques++;
	}

	if( iQtdCheques == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

	/* Comentario do Vagner:
	   Nesta parte, o processo vai tentar vincular um cheque para uma
	   conta mesmo que os valores nao batam, desde que a diferenca seja
	   menor ou igual a ValorAjusteContabil, e caso seja possivel vincular,
	   sera gerado o ajuste contabil.
	*/

    /*****************************************
    ' * Quarta Fase do Vinculo               *
    ' * Vinculando Um Cheque para Uma Conta  *
	' * com diferenca <= ValorAjusteContabil *
    ' ****************************************/

	/* Comentario do Vagner:
	   Nesta fase, se o Cheque de Pagamento for do Unibanco
	   pode-se vincula-lo a qualquer Cobranca/Arrecadacao.
	   Se o Cheque de Pagamento nao for do Unibanco
	   somente vincula-o se a Cobranca for diferente
	   de "Titulos Terceiros Sem CB" (12) e diferente de
	   "Cobranca Terceiros" (31)
	*/

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CP" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo &&
			Doc.TipoDocto != 41 ) /* Nao fazer ajuste contabil para LI */
		{
            /*********************************************
            ' * Cheque ou ADCC a Verificar o Vinculo     *
            ' ********************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.TipoGenerico == "CO" && 
					DocAux.Vinculo == 0 && 
					!DocAux.DesprezarVinculo &&
					abs(Doc.Valor - DocAux.Valor) > 0 &&
				    abs(Doc.Valor - DocAux.Valor) <= Converte(m_pParametro->m_ValorAjusteContabil) )
				{
					if( (Doc.TipoDocto == 6 && DocAux.TipoDocto != 12 &&
						 DocAux.TipoDocto != 31) || Doc.TipoDocto == 5 ||
						 Doc.TipoDocto == 4 || Doc.TipoDocto == 41 )
					{
						/**********************************
						' * Vinculando Conta com o Cheque *
						' *********************************/
						m_ArrayDoc[i].Vinculo  = Doc.IdDocto;
						m_ArrayDoc[j].Vinculo  = Doc.IdDocto;
						/**************************************
						' * Corrige o tipodocumento do cheque *
						' *************************************/
						if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
						{
							if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230") )
							{
								m_ArrayDoc[i].TipoDocto = 5;
								if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
								{
									m_ArrayDoc[i].Alcada = TRUE;
								}
								else
								{
									m_ArrayDoc[i].Alcada = FALSE;
								}
							}
							else
							{
								m_ArrayDoc[i].TipoDocto = 6;
								if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
								{
									m_ArrayDoc[i].Alcada = TRUE;
								}
								else
								{
									m_ArrayDoc[i].Alcada = FALSE;
								}
							}
						}

						/*****************************************
						' * Gravando Ajuste de D�bito ou Cr�dito *
						' ****************************************/
						if( !InsereAjuste( (Doc.Valor > DocAux.Valor ? 42 : 43), 
										   0, "0", abs(Doc.Valor - DocAux.Valor), IdDocto ) )
						{
							return 0;
						}
						Ajuste.Alcada = FALSE;
						Ajuste.DesprezarVinculo = FALSE;
						Ajuste.IdDocto = IdDocto;
						Ajuste.TipoDocto = (Doc.Valor > DocAux.Valor ? 42 : 43);
						Ajuste.TipoGenerico = (Doc.Valor > DocAux.Valor ? "AC" : "AD");
						Ajuste.Valor = abs(Doc.Valor - DocAux.Valor);
						Ajuste.Vinculo = Doc.IdDocto;
						m_ArrayDoc.InsertAt(0, Ajuste, 1);

						break;
					}
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}
    
	
	/**********************************
    ' * Verificar se ainda existe     *
    ' * Documentos a serem vinculados *
    ' *********************************/
    iQtdSemVinculo = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoGenerico == "CO" || Doc.TipoGenerico == "CP") &&
			 Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdSemVinculo++;
	}

	if( iQtdSemVinculo == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

    iQtdChPagto = 0;
	iQtdChTerc  = 0;
	iQtdADCC    = 0;
	iQtdLI      = 0;
	
	/******************************************
    ' * Verificar se pode Vincular o Restante *
    ' *****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoDocto == 5 )
		{
			iQtdChPagto++;
		}
		else if( Doc.TipoDocto >= 6 && Doc.TipoDocto <= 7 && Doc.Vinculo == 0 )
		{
			iQtdChTerc++;
		}
		else if( Doc.TipoDocto == 4 && Doc.Vinculo == 0 )
		{
			iQtdADCC++;
		}
		else if( Doc.TipoDocto == 41 && Doc.Vinculo == 0 )
		{
			iQtdLI++;
		}
		else if( Doc.DesprezarVinculo && Doc.Vinculo == 0 )
		{
			/* Comentario do Vagner:
			   Caso exista algum docto marcado para desprezar
			   vinculo, eh porque existem varios doctos com
			   mesmo valor, por isso nao se pode vincula-los
			   automaticamente
			*/
			return 1;
		}
	}
	
	if( iQtdChTerc > 0 )
	{
		/* Comentario do Vagner:
		   Nao se pode vincular mais de um cheque que nao seja do Unibanco
		*/
		return 1;
	}
	else if( iQtdChPagto > 0 && iQtdADCC > 0 )
	{
		/* Comentario do Vagner:
		   Nao se pode vincular ADCC com Cheque
		*/
		return 1;
	}
	
	/* Comentario do Vagner:
	   Se o processo chegou ate este ponto, entao tudo que poderia
	   ser vinculado 1 para 1 ou 1 para N ja foi vinculado,
	   alem disso nao existem valores repetidos que poderiam gerar
	   varias alternativas de vinculo.
	   Entao, basta vincular todos os cheques de pagamento do Unibanco
	   que sobraram com as varias contas que sobraram, 
	   mas para isso os valores devem bater
	*/

    /**********************************
    ' * Verificar se Existe Diferen�a *
    ' *********************************/
	Diferenca    = 0;
	ValorCheques = 0;
	ValorContas  = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.Vinculo == 0 && Doc.TipoDocto == 5 ) 
		{
			ValorCheques += Doc.Valor;
		}
		else if( Doc.Vinculo == 0 && Doc.TipoGenerico == "CO" ) 
		{
			ValorContas += Doc.Valor;
		}
	}
	
	Diferenca = ValorCheques - ValorContas;

	/******************************************
	' * Quinta Fase do Vinculo                *
	' * Vinculando n Contas com n Cheques     *
	' *****************************************/
	if( Diferenca == 0 )
	{
		iVinculo = 0;

		for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
		{
			Doc = m_ArrayDoc[i];
			if( (Doc.TipoDocto == 5 || Doc.TipoGenerico == "CO") 
				 && Doc.Vinculo == 0 )
			{
				/********************************
				' * Vinculando Contas e Cheques *
				' *******************************/
				if( iVinculo == 0 )
					iVinculo = Doc.IdDocto;

				m_ArrayDoc[i].Vinculo = iVinculo;
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /*********************************************
    ' * Verificando a Qtde de Contas no Malote   *
    ' * A Serem Vinculadas                       *
    ' *******************************************/
    iQtdContas = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CO" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdContas++;
	}

	if( iQtdContas == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

	/* Comentario do Vagner:
	   Nesta fase, se, e somente se, o Cheque de Pagamento for 
	   do Unibanco pode-se vincula-lo a qualquer Cobranca/Arrecadacao.
	*/

    /*****************************************
    ' * Sexta Fase do Vinculo                *
    ' * Vinculando Um Cheque a v�rias Contas *
	' * com diferenca <= ValorAjusteContabil *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto == 4 || Doc.TipoDocto == 5 ) && 
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo ) 
			/* Nao fazer ajuste contabil para LI */
		{
            /*********************************************
            ' * Cheque ou ADCC a Verificar o Vinculo     *
            ' ********************************************/
			iInicio    = 1;
			iDesprezar = 1;
			while( iInicio <= iQtdContas )
			{
				ValorVinculo = 0;
				iConta       = 0;

				aIndConta.RemoveAll();
				for( j = 0; j < iQtdContas; j++ )
					aIndConta.Add(-1);

				for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
				{
					DocAux = m_ArrayDoc[j];
					if( DocAux.TipoGenerico == "CO" && 
						DocAux.Vinculo == 0 && 
						!DocAux.DesprezarVinculo )
					{
						iConta++;
						if( iConta == iInicio || iConta > iDesprezar )
						{
							ValorVinculo += DocAux.Valor;
							aIndConta[iConta-1] = j;
							if( abs(Doc.Valor - ValorVinculo) <= 
								Converte(m_pParametro->m_ValorAjusteContabil) )
								break;
						}
					}
				}
				if( iInicio % 50 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}

				/*******************************************************
				 * Verifica se o Valor da Combinacao menos             *
				 * o valor do cheque, e menor que ValorAjusteContabil  *
				 *******************************************************/
				if( abs(Doc.Valor - ValorVinculo) > 0 &&
					abs(Doc.Valor - ValorVinculo) <= 
					Converte(m_pParametro->m_ValorAjusteContabil) )
				{
					m_ArrayDoc[i].Vinculo = Doc.IdDocto;
					/**************************************
					' * Corrige o tipodocumento do cheque *
					' *************************************/
					if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
					{
						if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230") )
						{
							m_ArrayDoc[i].TipoDocto = 5;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
						else
						{
							m_ArrayDoc[i].TipoDocto = 6;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
					}

					for( j = 0; j < iQtdContas; j++ )
					{
						if( aIndConta[j] >= 0 )
						{
							m_ArrayDoc[aIndConta[j]].Vinculo = Doc.IdDocto;
						}
					}

					/*****************************************
					' * Gravando Ajuste de D�bito ou Cr�dito *
					' ****************************************/
					if( !InsereAjuste( (Doc.Valor > ValorVinculo ? 42 : 43), 
									   0, "0", abs(Doc.Valor - ValorVinculo), IdDocto ) )
					{
						return 0;
					}
					Ajuste.Alcada = FALSE;
					Ajuste.DesprezarVinculo = FALSE;
					Ajuste.IdDocto = IdDocto;
					Ajuste.TipoDocto = (Doc.Valor > ValorVinculo ? 42 : 43);
					Ajuste.TipoGenerico = (Doc.Valor > ValorVinculo ? "AC" : "AD");
					Ajuste.Valor = abs(Doc.Valor - ValorVinculo);
					Ajuste.Vinculo = Doc.IdDocto;
					m_ArrayDoc.InsertAt(0, Ajuste, 1);
					
					break;
				}

				iDesprezar++;
				if( iDesprezar >= iQtdContas )
				{
					iInicio++;
					iDesprezar = iInicio;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /********************************************
    ' * Verificando a Qtde de Cheques no Malote *
    ' * A Serem Vinculados                      *
    ' *******************************************/
    iQtdCheques = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto >= 4 && Doc.TipoDocto < 7 || Doc.TipoDocto == 41) &&
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdCheques++;
	}

	if( iQtdCheques == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

	/* Comentario do Vagner:
	   Nesta fase, se, e somente se, todos os Cheques de Pagamento forem 
	   do Unibanco pode-se vincula-los a qualquer Cobranca/Arrecadacao.
	*/

    /******************************************
    ' * Setima Fase do Vinculo                *
    ' * Vinculando Uma Conta a v�rios Cheques *
	' * com diferenca <= ValorAjusteContabil  *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CO" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /********************************
            ' * Conta a Verificar o Vinculo *
            ' *******************************/
			iInicio    = 1;
			iDesprezar = 1;
			while( iInicio <= iQtdCheques )
			{
				ValorVinculo = 0;
				iCheque      = 0;
				iQtdChPagto  = 0;
				iQtdADCC     = 0;

				aIndCheque.RemoveAll();
				for( j = 0; j < iQtdCheques; j++ )
					aIndCheque.Add(-1);

				for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
				{
					DocAux = m_ArrayDoc[j];
					if( (DocAux.TipoDocto == 4 || DocAux.TipoDocto == 5) && 
						DocAux.Vinculo == 0 && !DocAux.DesprezarVinculo )
						/* Nao fazer ajuste contabil para LI */
					{
						iCheque++;
						if( iCheque == iInicio || iCheque > iDesprezar )
						{
							if( DocAux.TipoDocto == 4 )
								iQtdADCC++;
							else if( DocAux.TipoDocto == 5 )
								iQtdChPagto++;
							ValorVinculo += DocAux.Valor;
							aIndCheque[iCheque-1] = j;
							if( abs(ValorVinculo - Doc.Valor) <= 
								Converte(m_pParametro->m_ValorAjusteContabil) )
								break;
						}
					}
				}
				if( iInicio % 50 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}

				/*****************************************************
				 * Verifica se o Valor da Combinacao menos           *
				 * o valor da conta, e menor que ValorAjusteContabil *
				 *****************************************************/
				if( abs(ValorVinculo - Doc.Valor) > 0 &&
					abs(ValorVinculo - Doc.Valor) <= 
					Converte(m_pParametro->m_ValorAjusteContabil) )
				{
					/* Nao pode haver cheque vinculado com ADCC */
					if( iQtdChPagto == 0 || iQtdADCC == 0 )
					{
						m_ArrayDoc[i].Vinculo = Doc.IdDocto;
						for( j = 0; j < iQtdCheques; j++ )
						{
							if( aIndCheque[j] >= 0 )
							{
								m_ArrayDoc[aIndCheque[j]].Vinculo = Doc.IdDocto;
							}
						}

						/*****************************************
						' * Gravando Ajuste de D�bito ou Cr�dito *
						' ****************************************/
						if( !InsereAjuste( (ValorVinculo > Doc.Valor ? 42 : 43), 
										   0, "0", abs(ValorVinculo - Doc.Valor), IdDocto ) )
						{
							return 0;
						}
						Ajuste.Alcada = FALSE;
						Ajuste.DesprezarVinculo = FALSE;
						Ajuste.IdDocto = IdDocto;
						Ajuste.TipoDocto = (ValorVinculo > Doc.Valor ? 42 : 43);
						Ajuste.TipoGenerico = (ValorVinculo > Doc.Valor ? "AC" : "AD");
						Ajuste.Valor = abs(ValorVinculo - Doc.Valor);
						Ajuste.Vinculo = Doc.IdDocto;
						m_ArrayDoc.InsertAt(0, Ajuste, 1);
						
						break;
					}
				}

				iDesprezar++;
				if( iDesprezar >= iQtdCheques )
				{
					iInicio++;
					iDesprezar = iInicio;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

	/**********************************
    ' * Verificar se ainda existe     *
    ' * Documentos a serem vinculados *
    ' *********************************/
    iQtdSemVinculo = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoGenerico == "CO" || Doc.TipoGenerico == "CP") &&
			 Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdSemVinculo++;
	}

	if( iQtdSemVinculo == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

    /**********************************
    ' * Verificar se Existe Diferen�a *
    ' *********************************/
	Diferenca    = 0;
	ValorCheques = 0;
	ValorContas  = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.Vinculo == 0 && Doc.TipoDocto == 5 )  /* Nao fazer ajuste contabil para LI */
		{
			ValorCheques += Doc.Valor;
		}
		else if( Doc.Vinculo == 0 && Doc.TipoGenerico == "CO" ) 
		{
			ValorContas += Doc.Valor;
		}
	}
	
	Diferenca = ValorCheques - ValorContas;

	/******************************************
	' * Oitava Fase do Vinculo                *
	' * Vinculando n Contas com n Cheques     *
	' * com diferenca <= ValorAjusteContabil  *
	' *****************************************/
	if( abs(Diferenca) >= 0 && 
		abs(Diferenca) <= Converte(m_pParametro->m_ValorAjusteContabil) )
	{
		iVinculo = 0;

		for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
		{
			Doc = m_ArrayDoc[i];
			if( (Doc.TipoDocto == 5 || Doc.TipoGenerico == "CO") 
				 && Doc.Vinculo == 0 )
			{
				/********************************
				' * Vinculando Contas e Cheques *
				' *******************************/
				if( iVinculo == 0 )
					iVinculo = Doc.IdDocto;

				m_ArrayDoc[i].Vinculo = iVinculo;
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}

		if( abs(Diferenca) > 0 )
		{
			/*****************************************
			' * Gravando Ajuste de D�bito ou Cr�dito *
			' ****************************************/
			if( !InsereAjuste( (Diferenca > 0 ? 42 : 43), 
							   0, "0", abs(Diferenca), IdDocto ) )
			{
				return 0;
			}
			Ajuste.Alcada = FALSE;
			Ajuste.DesprezarVinculo = FALSE;
			Ajuste.IdDocto = IdDocto;
			Ajuste.TipoDocto = (Diferenca > 0 ? 42 : 43);
			Ajuste.TipoGenerico = (Diferenca > 0 ? "AC" : "AD");
			Ajuste.Valor = abs(Diferenca);
			Ajuste.Vinculo = iVinculo;
			m_ArrayDoc.InsertAt(0, Ajuste, 1);
		}
	}

	// Sucesso !

	return 1;

}

// retorna: -1 se erro; 0 se nao vinculou; 1 se vinculou
int CVinculador::VinculaDocumentoMaloteRegraAntiga( void )
{
	DOCUMENTO Doc, DocAux, Ajuste;
	int i, j, iQtdCheques, iQtdContas;
	int iQtdSemVinculo, iQtdADCC, iQtdLI, iQtdChPagto;
	long iVinculo;
	__int64 ValorVinculo, Diferenca, ValorCheques, ValorContas;
	int iConta, iCheque;
	int iInicio, iDesprezar;
	long IdDocto;
	CArray<int, int> aIndConta;
	CArray<int, int> aIndCheque;

	/* Comentario do Vagner:
	   Este algoritmo foi desenvolvido pela Proservvi,
	   por absoluta falta de tempo, ele nao pode ser
	   melhorado, mas ele funciona na grande maioria dos casos.
	*/

	/*****************************************
    ' * Marcar para Desprezar para o V�nculo *
    ' * Os Cheques com o mesmo Valor         *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		iQtdCheques = 0;
		iQtdContas  = 0;

		Doc = m_ArrayDoc[i];
		
		if( Doc.DesprezarVinculo == FALSE && Doc.Vinculo == 0 && 
			Doc.TipoDocto > 3 && Doc.TipoDocto <= 6 )
		{
            /****************************
            ' * Cheque/ADCC sem V�nculo *
            ' ***************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.Vinculo == 0 && DocAux.Valor == Doc.Valor )
				{
					if( DocAux.TipoDocto > 3 && DocAux.TipoDocto <= 6 )
					{
                        /*******************************
                        ' * Cheque/ADCC no Mesmo Valor *
                        ' ******************************/
						iQtdCheques++;
					}
					else if( DocAux.TipoGenerico == "CO" )
					{
                        /*************************
                        ' * Conta no mesmo Valor *
                        ' ************************/
						iQtdContas++;
					}
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}

		if( iQtdContas > 1 && m_QtdChequePagto > 1 )
		{
            /*************************************************
            ' * Desprezar para o V�nculo Autom�tico          *
            ' ************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdContas > 1 && iQtdCheques > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdCheques > 1 && m_QtdContas > 1 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdCheques > 1 && iQtdContas > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}

		if( m_ArrayDoc[i].DesprezarVinculo )
		{
            /*****************************************
            ' * Marcar para Desprezar para o V�nculo *
            ' * Todos que tenham o mesmo valor       *
            ' ****************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				if( Doc.Valor == m_ArrayDoc[j].Valor )
					m_ArrayDoc[j].DesprezarVinculo = TRUE;
			}
		}
	}

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		iQtdContas     = 0;
		iQtdCheques    = 0;

		Doc = m_ArrayDoc[i];
		if( Doc.DesprezarVinculo == FALSE && Doc.Vinculo == 0 && 
			Doc.TipoGenerico == "CO" )
		{
            /***********************
            ' * Cheque sem V�nculo *
            ' **********************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.Vinculo == 0 && DocAux.Valor == Doc.Valor )
				{
					if( DocAux.TipoDocto > 3 && DocAux.TipoDocto <= 6 )
						iQtdCheques++;
					else if( DocAux.TipoGenerico == "CO" )
						iQtdContas++;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}


		if( iQtdCheques > 1 && m_QtdContas > 1 )
		{
            /*************************************************
            ' * Desprezar para o V�nculo Autom�tico          *
            ' ************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdCheques > 1 && iQtdContas > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdContas > 1 && m_QtdChequePagto > 1 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdContas > 1 && iQtdCheques > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}

		if( m_ArrayDoc[i].DesprezarVinculo )
		{
            /*****************************************
            ' * Marcar para Desprezar para o V�nculo *
            ' * Todos que tenham o mesmo valor       *
            ' ****************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				if( Doc.Valor == m_ArrayDoc[j].Valor )
					m_ArrayDoc[j].DesprezarVinculo = TRUE;
			}
		}
		
	}

    /****************************************
    ' * Primeira Fase do Vinculo            *
    ' * Vinculando Um Cheque para Uma Conta *
    ' ***************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CP" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /*****************************************
            ' * Cheque ou ADCC a Verificar o Vinculo *
            ' ****************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.TipoGenerico == "CO" && 
					DocAux.Vinculo == 0 && 
					!DocAux.DesprezarVinculo &&
					Doc.Valor == DocAux.Valor )
				{
                    /**********************************
                    ' * Vinculando Conta com o Cheque *
                    ' *********************************/
					m_ArrayDoc[i].Vinculo  = Doc.IdDocto;
					m_ArrayDoc[j].Vinculo  = Doc.IdDocto;
					/**************************************
					' * Corrige o tipodocumento do cheque *
					' *************************************/
					if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
					{
						if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230"))
						{
							m_ArrayDoc[i].TipoDocto = 5;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
						else
						{
							m_ArrayDoc[i].TipoDocto = 6;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
					}
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /*******************************************
    ' * Verificando a Qtde de Contas no Malote *
    ' * A Serem Vinculadas                     *
    ' ******************************************/
    iQtdContas = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CO" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdContas++;
	}

	if( iQtdContas == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

	/* Comentario do Vagner:
	   Nesta segunda fase o algoritmo tenta vincular um cheque com
	   uma combinacao das contas, esta combinacao comeca com n, depois
	   tenta n-1, n-2, ...
	   Porem ele so testa combinacoes com documentos adjacentes, 
	   ele nao verifica todas as combinacoes possiveis.
	*/

    /*****************************************
    ' * Segunda Fase do Vinculo              *
    ' * Vinculando Um Cheque a v�rias Contas *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CP" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /*****************************************
            ' * Cheque ou ADCC a Verificar o Vinculo *
            ' ****************************************/
			iInicio    = 1;
			iDesprezar = 1;
			while( iInicio <= iQtdContas )
			{
				ValorVinculo = 0;
				iConta       = 0;

				aIndConta.RemoveAll();
				for( j = 0; j < iQtdContas; j++ )
					aIndConta.Add(-1);

				for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
				{
					DocAux = m_ArrayDoc[j];
					if( DocAux.TipoGenerico == "CO" && 
						DocAux.Vinculo == 0 && 
						!DocAux.DesprezarVinculo )
					{
						iConta++;
						if( iConta == iInicio || iConta > iDesprezar )
						{
							ValorVinculo += DocAux.Valor;
							aIndConta[iConta-1] = j;
							if( ValorVinculo >= Doc.Valor )
								break;
						}
					}
				}
				if( iInicio % 50 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}

				/**********************************************
				 * Verifica se o Valor da Combinacao bate com *
				 * o valor do cheque, entao vincula           *
				 **********************************************/
				if( ValorVinculo == Doc.Valor )
				{
					m_ArrayDoc[i].Vinculo = Doc.IdDocto;
					/**************************************
					' * Corrige o tipodocumento do cheque *
					' *************************************/
					if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
					{
						if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230") )
						{
							m_ArrayDoc[i].TipoDocto = 5;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
						else
						{
							m_ArrayDoc[i].TipoDocto = 6;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
					}

					for( j = 0; j < iQtdContas; j++ )
					{
						if( aIndConta[j] >= 0 )
						{
							m_ArrayDoc[aIndConta[j]].Vinculo = Doc.IdDocto;
						}
					}
					break;
				}

				iDesprezar++;
				if( iDesprezar >= iQtdContas )
				{
					iInicio++;
					iDesprezar = iInicio;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /********************************************
    ' * Verificando a Qtde de Cheques no Malote *
    ' * A Serem Vinculados                      *
    ' *******************************************/
    iQtdCheques = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto >= 4 && Doc.TipoDocto < 7 || Doc.TipoDocto == 41) &&
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdCheques++;
	}

	if( iQtdCheques == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

	/* Comentario do Vagner:
	   Nesta segunda fase o algoritmo tenta vincular uma conta com
	   uma combinacao dos cheques, esta combinacao comeca com n, depois
	   tenta n-1, n-2, ...
	   Porem ele so testa combinacoes com documentos adjacentes, 
	   ele nao verifica todas as combinacoes possiveis.
	*/

    /******************************************
    ' * Terceira Fase do Vinculo              *
    ' * Vinculando Uma Conta a v�rios Cheques *
    ' *****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CO" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /********************************
            ' * Conta a Verificar o Vinculo *
            ' *******************************/
			iInicio    = 1;
			iDesprezar = 1;
			while( iInicio <= iQtdCheques )
			{
				ValorVinculo = 0;
				iCheque      = 0;
				iQtdChPagto  = 0;
				iQtdADCC     = 0;
				iQtdLI       = 0;

				aIndCheque.RemoveAll();
				for( j = 0; j < iQtdCheques; j++ )
					aIndCheque.Add(-1);

				for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
				{
					DocAux = m_ArrayDoc[j];
					if( DocAux.TipoGenerico == "CP" && 
						DocAux.Vinculo == 0 && 
						!DocAux.DesprezarVinculo )
					{
						iCheque++;
						if( iCheque == iInicio || iCheque > iDesprezar )
						{
							if( DocAux.TipoDocto == 4 )
								iQtdADCC++;
							else if( DocAux.TipoDocto >= 5 && DocAux.TipoDocto <= 7 )
								iQtdChPagto++;
							else if( DocAux.TipoDocto == 41 )
								iQtdLI++;
							ValorVinculo += DocAux.Valor;
							aIndCheque[iCheque-1] = j;
							if( ValorVinculo >= Doc.Valor )
								break;
						}
					}
				}
				if( iInicio % 50 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}

				/**********************************************
				 * Verifica se o Valor da Combinacao bate com *
				 * o valor da conta, entao vincula            *
				 **********************************************/
				if( ValorVinculo == Doc.Valor )
				{
					/* Nao pode haver cheque vinculado com ADCC */
					if( iQtdChPagto == 0 || iQtdADCC == 0 )
					{
						m_ArrayDoc[i].Vinculo = Doc.IdDocto;
						for( j = 0; j < iQtdCheques; j++ )
						{
							if( aIndCheque[j] >= 0 )
							{
								m_ArrayDoc[aIndCheque[j]].Vinculo = Doc.IdDocto;
								/***********************************************
								 * Se cheque Ubb transforma em cheque terceiro *
								 ***********************************************/
								if( m_ArrayDoc[aIndCheque[j]].TipoDocto == 5  ||
									m_ArrayDoc[aIndCheque[j]].TipoDocto == 7 )
								{
									m_ArrayDoc[aIndCheque[j]].TipoDocto = 6;
									if(	m_ArrayDoc[aIndCheque[j]].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
									{
										m_ArrayDoc[aIndCheque[j]].Alcada = TRUE;
									}
									else
									{
										m_ArrayDoc[aIndCheque[j]].Alcada = FALSE;
									}
								}
							}
						}
						break;
					}
				}

				iDesprezar++;
				if( iDesprezar >= iQtdCheques )
				{
					iInicio++;
					iDesprezar = iInicio;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /**********************************************
    ' * Verificando a Qtde de Cheques no Malote   *
    ' * A Serem Vinculados                        *
    ' ********************************************/
    iQtdCheques = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto >= 4 && Doc.TipoDocto < 7 || Doc.TipoDocto == 41) &&
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdCheques++;
	}

	if( iQtdCheques == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

	/* Comentario do Vagner:
	   Nesta parte, o processo vai tentar vincular um cheque para uma
	   conta mesmo que os valores nao batam, desde que a diferenca seja
	   menor ou igual a ValorAjusteContabil, e caso seja possivel vincular,
	   sera gerado o ajuste contabil.
	*/

    /*****************************************
    ' * Quarta Fase do Vinculo               *
    ' * Vinculando Um Cheque para Uma Conta  *
	' * com diferenca <= ValorAjusteContabil *
    ' ****************************************/

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CP" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo &&
			Doc.TipoDocto != 41 ) /* Nao fazer ajuste contabil para LI */
		{
            /*********************************************
            ' * Cheque ou ADCC a Verificar o Vinculo     *
            ' ********************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.TipoGenerico == "CO" && 
					DocAux.Vinculo == 0 && 
					!DocAux.DesprezarVinculo &&
					abs(Doc.Valor - DocAux.Valor) > 0 &&
				    abs(Doc.Valor - DocAux.Valor) <= Converte(m_pParametro->m_ValorAjusteContabil) )
				{
					/**********************************
					' * Vinculando Conta com o Cheque *
					' *********************************/
					m_ArrayDoc[i].Vinculo  = Doc.IdDocto;
					m_ArrayDoc[j].Vinculo  = Doc.IdDocto;
					/**************************************
					' * Corrige o tipodocumento do cheque *
					' *************************************/
					if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
					{
						if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230") )
						{
							m_ArrayDoc[i].TipoDocto = 5;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
						else
						{
							m_ArrayDoc[i].TipoDocto = 6;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
					}

					/*****************************************
					' * Gravando Ajuste de D�bito ou Cr�dito *
					' ****************************************/
					if( !InsereAjuste( (Doc.Valor > DocAux.Valor ? 42 : 43), 
									   0, "0", abs(Doc.Valor - DocAux.Valor), IdDocto ) )
					{
						return 0;
					}
					Ajuste.Alcada = FALSE;
					Ajuste.DesprezarVinculo = FALSE;
					Ajuste.IdDocto = IdDocto;
					Ajuste.TipoDocto = (Doc.Valor > DocAux.Valor ? 42 : 43);
					Ajuste.TipoGenerico = (Doc.Valor > DocAux.Valor ? "AC" : "AD");
					Ajuste.Valor = abs(Doc.Valor - DocAux.Valor);
					Ajuste.Vinculo = Doc.IdDocto;
					m_ArrayDoc.InsertAt(0, Ajuste, 1);

					break;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

	/**********************************
    ' * Verificar se ainda existe     *
    ' * Documentos a serem vinculados *
    ' *********************************/
    iQtdSemVinculo = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoGenerico == "CO" || Doc.TipoGenerico == "CP") &&
			 Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdSemVinculo++;
	}

	if( iQtdSemVinculo == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

    iQtdChPagto = 0;
	iQtdADCC    = 0;
	iQtdLI      = 0;
	
	/******************************************
    ' * Verificar se pode Vincular o Restante *
    ' *****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoDocto >= 5 && Doc.TipoDocto <= 7 && Doc.Vinculo == 0 )
		{
			iQtdChPagto++;
		}
		else if( Doc.TipoDocto == 4 && Doc.Vinculo == 0 )
		{
			iQtdADCC++;
		}
		else if( Doc.TipoDocto == 41 && Doc.Vinculo == 0 )
		{
			iQtdLI++;
		}
		else if( Doc.DesprezarVinculo && Doc.Vinculo == 0 )
		{
			/* Comentario do Vagner:
			   Caso exista algum docto marcado para desprezar
			   vinculo, eh porque existem varios doctos com
			   mesmo valor, por isso nao se pode vincula-los
			   automaticamente
			*/
			return 1;
		}
	}
	
	if( iQtdChPagto > 0 && iQtdADCC > 0 )
	{
		/* Comentario do Vagner:
		   Nao se pode vincular ADCC com Cheque
		*/
		return 1;
	}
	
	/* Comentario do Vagner:
	   Se o processo chegou ate este ponto, entao tudo que poderia
	   ser vinculado 1 para 1 ou 1 para N ja foi vinculado,
	   alem disso nao existem valores repetidos que poderiam gerar
	   varias alternativas de vinculo.
	   Entao, basta vincular todos os cheques de pagamento do Unibanco
	   que sobraram com as varias contas que sobraram, 
	   mas para isso os valores devem bater
	*/
	
	/**********************************
    ' * Verificar se Existe Diferen�a *
    ' *********************************/
	Diferenca    = 0;
	ValorCheques = 0;
	ValorContas  = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.Vinculo == 0 && (Doc.TipoGenerico == "CP" || Doc.TipoDocto == 38) ) // AD
		{
			ValorCheques += Doc.Valor;
		}
		else if( Doc.Vinculo == 0 && (Doc.TipoGenerico == "CO" || Doc.TipoDocto == 34) ) // AC
		{
			ValorContas += Doc.Valor;
		}
	}
	
	Diferenca = ValorCheques - ValorContas;
    
	/******************************************
	' * Quinta Fase do Vinculo                *
	' * Vinculando n Contas com n Cheques     *
	' *****************************************/
	if( Diferenca == 0 )
	{
		iVinculo = 0;

		for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
		{
			Doc = m_ArrayDoc[i];
			if( (Doc.TipoGenerico == "CP" || Doc.TipoGenerico == "CO") 
				 && Doc.Vinculo == 0 )
			{
				/********************************
				' * Vinculando Contas e Cheques *
				' *******************************/
				if( iVinculo == 0 )
					iVinculo = Doc.IdDocto;

				m_ArrayDoc[i].Vinculo = iVinculo;
				/***********************************************
				 * Se cheque Ubb transforma em cheque terceiro *
				 ***********************************************/
				if( Doc.TipoDocto == 5 || Doc.TipoDocto == 7)
				{
					m_ArrayDoc[i].TipoDocto = 6;
					if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
					{
						m_ArrayDoc[i].Alcada = TRUE;
					}
					else
					{
						m_ArrayDoc[i].Alcada = FALSE;
					}
				}

			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}
	
    /*********************************************
    ' * Verificando a Qtde de Contas no Malote   *
    ' * A Serem Vinculadas                       *
    ' *******************************************/
    iQtdContas = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CO" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdContas++;
	}

	if( iQtdContas == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

    /*****************************************
    ' * Sexta Fase do Vinculo                *
    ' * Vinculando Um Cheque a v�rias Contas *
	' * com diferenca <= ValorAjusteContabil *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CP" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo &&
			Doc.TipoDocto != 41 ) /* Nao fazer ajuste contabil para LI */
		{
            /*********************************************
            ' * Cheque ou ADCC a Verificar o Vinculo     *
            ' ********************************************/
			iInicio    = 1;
			iDesprezar = 1;
			while( iInicio <= iQtdContas )
			{
				ValorVinculo = 0;
				iConta       = 0;

				aIndConta.RemoveAll();
				for( j = 0; j < iQtdContas; j++ )
					aIndConta.Add(-1);

				for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
				{
					DocAux = m_ArrayDoc[j];
					if( DocAux.TipoGenerico == "CO" && 
						DocAux.Vinculo == 0 && 
						!DocAux.DesprezarVinculo )
					{
						iConta++;
						if( iConta == iInicio || iConta > iDesprezar )
						{
							ValorVinculo += DocAux.Valor;
							aIndConta[iConta-1] = j;
							if( abs(Doc.Valor - ValorVinculo) <= 
								Converte(m_pParametro->m_ValorAjusteContabil) )
								break;
						}
					}
				}
				if( iInicio % 50 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}

				/*******************************************************
				 * Verifica se o Valor da Combinacao menos             *
				 * o valor do cheque, e menor que ValorAjusteContabil  *
				 *******************************************************/
				if( abs(Doc.Valor - ValorVinculo) > 0 &&
					abs(Doc.Valor - ValorVinculo) <= 
					Converte(m_pParametro->m_ValorAjusteContabil) )
				{
					m_ArrayDoc[i].Vinculo = Doc.IdDocto;
					/**************************************
					' * Corrige o tipodocumento do cheque *
					' *************************************/
					if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
					{
						if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230") )
						{
							m_ArrayDoc[i].TipoDocto = 5;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
						else
						{
							m_ArrayDoc[i].TipoDocto = 6;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
					}

					for( j = 0; j < iQtdContas; j++ )
					{
						if( aIndConta[j] >= 0 )
						{
							m_ArrayDoc[aIndConta[j]].Vinculo = Doc.IdDocto;
						}
					}

					/*****************************************
					' * Gravando Ajuste de D�bito ou Cr�dito *
					' ****************************************/
					if( !InsereAjuste( (Doc.Valor > ValorVinculo ? 42 : 43), 
									   0, "0", abs(Doc.Valor - ValorVinculo), IdDocto ) )
					{
						return 0;
					}
					Ajuste.Alcada = FALSE;
					Ajuste.DesprezarVinculo = FALSE;
					Ajuste.IdDocto = IdDocto;
					Ajuste.TipoDocto = (Doc.Valor > ValorVinculo ? 42 : 43);
					Ajuste.TipoGenerico = (Doc.Valor > ValorVinculo ? "AC" : "AD");
					Ajuste.Valor = abs(Doc.Valor - ValorVinculo);
					Ajuste.Vinculo = Doc.IdDocto;
					m_ArrayDoc.InsertAt(0, Ajuste, 1);
					
					break;
				}

				iDesprezar++;
				if( iDesprezar >= iQtdContas )
				{
					iInicio++;
					iDesprezar = iInicio;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /********************************************
    ' * Verificando a Qtde de Cheques no Malote *
    ' * A Serem Vinculados                      *
    ' *******************************************/
    iQtdCheques = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto >= 4 && Doc.TipoDocto < 7 || Doc.TipoDocto == 41) &&
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdCheques++;
	}

	if( iQtdCheques == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

    /******************************************
    ' * Setima Fase do Vinculo                *
    ' * Vinculando Uma Conta a v�rios Cheques *
	' * com diferenca <= ValorAjusteContabil  *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CO" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /********************************
            ' * Conta a Verificar o Vinculo *
            ' *******************************/
			iInicio    = 1;
			iDesprezar = 1;
			while( iInicio <= iQtdCheques )
			{
				ValorVinculo = 0;
				iCheque      = 0;
				iQtdChPagto  = 0;
				iQtdADCC     = 0;

				aIndCheque.RemoveAll();
				for( j = 0; j < iQtdCheques; j++ )
					aIndCheque.Add(-1);

				for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
				{
					DocAux = m_ArrayDoc[j];
					if( DocAux.TipoGenerico == "CP" && 
						DocAux.Vinculo == 0 && !DocAux.DesprezarVinculo &&
						DocAux.TipoDocto != 41 ) /* Nao fazer ajuste contabil para LI */
					{
						iCheque++;
						if( iCheque == iInicio || iCheque > iDesprezar )
						{
							if( DocAux.TipoDocto == 4 )
								iQtdADCC++;
							else if( DocAux.TipoDocto >= 5 && DocAux.TipoDocto <= 7 )
								iQtdChPagto++;
							ValorVinculo += DocAux.Valor;
							aIndCheque[iCheque-1] = j;
							if( abs(ValorVinculo - Doc.Valor) <= 
								Converte(m_pParametro->m_ValorAjusteContabil) )
								break;
						}
					}
				}
				if( iInicio % 50 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}

				/*****************************************************
				 * Verifica se o Valor da Combinacao menos           *
				 * o valor da conta, e menor que ValorAjusteContabil *
				 *****************************************************/
				if( abs(ValorVinculo - Doc.Valor) > 0 &&
					abs(ValorVinculo - Doc.Valor) <= 
					Converte(m_pParametro->m_ValorAjusteContabil) )
				{
					/* Nao pode haver cheque vinculado com ADCC */
					if( iQtdChPagto == 0 || iQtdADCC == 0 )
					{
						m_ArrayDoc[i].Vinculo = Doc.IdDocto;
						for( j = 0; j < iQtdCheques; j++ )
						{
							if( aIndCheque[j] >= 0 )
							{
								m_ArrayDoc[aIndCheque[j]].Vinculo = Doc.IdDocto;
								/***********************************************
								 * Se cheque Ubb transforma em cheque terceiro *
								 ***********************************************/
								if( m_ArrayDoc[aIndCheque[j]].TipoDocto == 5  ||
									m_ArrayDoc[aIndCheque[j]].TipoDocto == 7 )
								{
									m_ArrayDoc[aIndCheque[j]].TipoDocto = 6;
									if(	m_ArrayDoc[aIndCheque[j]].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
									{
										m_ArrayDoc[aIndCheque[j]].Alcada = TRUE;
									}
									else
									{
										m_ArrayDoc[aIndCheque[j]].Alcada = FALSE;
									}
								}
							}
						}

						/*****************************************
						' * Gravando Ajuste de D�bito ou Cr�dito *
						' ****************************************/
						if( !InsereAjuste( (ValorVinculo > Doc.Valor ? 42 : 43), 
										   0, "0", abs(ValorVinculo - Doc.Valor), IdDocto ) )
						{
							return 0;
						}
						Ajuste.Alcada = FALSE;
						Ajuste.DesprezarVinculo = FALSE;
						Ajuste.IdDocto = IdDocto;
						Ajuste.TipoDocto = (ValorVinculo > Doc.Valor ? 42 : 43);
						Ajuste.TipoGenerico = (ValorVinculo > Doc.Valor ? "AC" : "AD");
						Ajuste.Valor = abs(ValorVinculo - Doc.Valor);
						Ajuste.Vinculo = Doc.IdDocto;
						m_ArrayDoc.InsertAt(0, Ajuste, 1);
						
						break;
					}
				}

				iDesprezar++;
				if( iDesprezar >= iQtdCheques )
				{
					iInicio++;
					iDesprezar = iInicio;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

	/**********************************
    ' * Verificar se ainda existe     *
    ' * Documentos a serem vinculados *
    ' *********************************/
    iQtdSemVinculo = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoGenerico == "CO" || Doc.TipoGenerico == "CP") &&
			 Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdSemVinculo++;
	}

	if( iQtdSemVinculo == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return 1;
	}

	/**********************************
    ' * Verificar se Existe Diferen�a *
    ' *********************************/
	Diferenca    = 0;
	ValorCheques = 0;
	ValorContas  = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.Vinculo == 0 && (Doc.TipoGenerico == "CP" || Doc.TipoDocto == 38) && 
			Doc.TipoDocto != 41 ) /* Nao fazer ajuste contabil para LI */
		{
			ValorCheques += Doc.Valor;
		}
		else if( Doc.Vinculo == 0 && (Doc.TipoGenerico == "CO" || Doc.TipoDocto == 34) ) 
		{
			ValorContas += Doc.Valor;
		}
	}
	
	Diferenca = ValorCheques - ValorContas;

	/******************************************
	' * Oitava Fase do Vinculo                *
	' * Vinculando n Contas com n Cheques     *
	' * com diferenca <= ValorAjusteContabil  *
	' *****************************************/
	if( abs(Diferenca) >= 0 && 
		abs(Diferenca) <= Converte(m_pParametro->m_ValorAjusteContabil) )
	{
		iVinculo = 0;

		for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
		{
			Doc = m_ArrayDoc[i];
			if( (Doc.TipoGenerico == "CP" || Doc.TipoGenerico == "CO") 
				 && Doc.Vinculo == 0 && Doc.TipoDocto != 41)
			{
				/********************************
				' * Vinculando Contas e Cheques *
				' *******************************/
				if( iVinculo == 0 )
					iVinculo = Doc.IdDocto;

				m_ArrayDoc[i].Vinculo = iVinculo;
				/***********************************************
				 * Se cheque Ubb transforma em cheque terceiro *
				 ***********************************************/
				if( Doc.TipoDocto == 5 || Doc.TipoDocto == 7)
				{
					m_ArrayDoc[i].TipoDocto = 6;
					if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
					{
						m_ArrayDoc[i].Alcada = TRUE;
					}
					else
					{
						m_ArrayDoc[i].Alcada = FALSE;
					}
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}

		if( abs(Diferenca) > 0 )
		{
			/*****************************************
			' * Gravando Ajuste de D�bito ou Cr�dito *
			' ****************************************/
			if( !InsereAjuste( (Diferenca > 0 ? 42 : 43), 
							   0, "0", abs(Diferenca), IdDocto ) )
			{
				return 0;
			}
			Ajuste.Alcada = FALSE;
			Ajuste.DesprezarVinculo = FALSE;
			Ajuste.IdDocto = IdDocto;
			Ajuste.TipoDocto = (Diferenca > 0 ? 42 : 43);
			Ajuste.TipoGenerico = (Diferenca > 0 ? "AC" : "AD");
			Ajuste.Valor = abs(Diferenca);
			Ajuste.Vinculo = iVinculo;
			m_ArrayDoc.InsertAt(0, Ajuste, 1);
		}
	}

	// Sucesso !

	return 1;
}


void CVinculador::VinculaDocumentoEnvelope( void )
{
	DOCUMENTO Doc, DocAux, Ajuste;
	int i, j, iQtdCheques, iQtdContas;
	__int64 ValorVinculo;
	long IdDocto;
	int iConta;
	int iInicio, iDesprezar;
	CArray<int, int> aIndConta;
	
	/* Comentario do Vagner:
	   Como o vinculo do envelope eh um subconjunto do vinculo
	   do malote, este algoritmo foi feito baseado no algoritimo
	   do vinculo do malote. Por absoluta falta de tempo nao
	   foi possivel criar um melhor.
	*/

	/*****************************************
    ' * Marcar para Desprezar para o V�nculo *
    ' * Os Cheques com o mesmo Valor         *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		iQtdCheques = 0;
		iQtdContas  = 0;

		Doc = m_ArrayDoc[i];
		
		if( Doc.DesprezarVinculo == FALSE && Doc.Vinculo == 0 && 
			Doc.TipoDocto > 3 && Doc.TipoDocto <= 6 )
		{
            /****************************
            ' * Cheque/ADCC sem V�nculo *
            ' ***************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.Vinculo == 0 && DocAux.Valor == Doc.Valor )
				{
					if( DocAux.TipoDocto > 3 && DocAux.TipoDocto <= 6 )
					{
                        /*******************************
                        ' * Cheque/ADCC no Mesmo Valor *
                        ' ******************************/
						iQtdCheques++;
					}
					else if( DocAux.TipoGenerico == "CO" )
					{
                        /*************************
                        ' * Conta no mesmo Valor *
                        ' ************************/
						iQtdContas++;
					}
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}

		if( iQtdContas > 1 && m_QtdChequePagto > 1 )
		{
            /*************************************************
            ' * Desprezar para o V�nculo Autom�tico          *
            ' ************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdContas > 1 && iQtdCheques > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdCheques > 1 && m_QtdContas > 1 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdCheques > 1 && iQtdContas > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}

		if( m_ArrayDoc[i].DesprezarVinculo )
		{
            /*****************************************
            ' * Marcar para Desprezar para o V�nculo *
            ' * Todos que tenham o mesmo valor       *
            ' ****************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				if( Doc.Valor == m_ArrayDoc[j].Valor )
					m_ArrayDoc[j].DesprezarVinculo = TRUE;
			}
		}
	}

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		iQtdContas     = 0;
		iQtdCheques    = 0;

		Doc = m_ArrayDoc[i];
		if( Doc.DesprezarVinculo == FALSE && Doc.Vinculo == 0 && 
			Doc.TipoGenerico == "CO" )
		{
            /***********************
            ' * Cheque sem V�nculo *
            ' **********************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.Vinculo == 0 && DocAux.Valor == Doc.Valor )
				{
					if( DocAux.TipoDocto > 3 && DocAux.TipoDocto <= 6 )
						iQtdCheques++;
					else if( DocAux.TipoGenerico == "CO" )
						iQtdContas++;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}


		if( iQtdCheques > 1 && m_QtdContas > 1 )
		{
            /*************************************************
            ' * Desprezar para o V�nculo Autom�tico          *
            ' ************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdCheques > 1 && iQtdContas > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdContas > 1 && m_QtdChequePagto > 1 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}
		else if( iQtdContas > 1 && iQtdCheques > 0 )
		{
            /***********************************************************
            ' * Desprezar para o V�nculo Autom�tico                    *
            ' **********************************************************/
			m_ArrayDoc[i].DesprezarVinculo = TRUE;
		}

		if( m_ArrayDoc[i].DesprezarVinculo )
		{
            /*****************************************
            ' * Marcar para Desprezar para o V�nculo *
            ' * Todos que tenham o mesmo valor       *
            ' ****************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				if( Doc.Valor == m_ArrayDoc[j].Valor )
					m_ArrayDoc[j].DesprezarVinculo = TRUE;
			}
		}
		
	}

    /****************************************
    ' * Primeira Fase do Vinculo            *
    ' * Vinculando Um Cheque para Uma Conta *
    ' ***************************************/

	/* Comentario do Vagner:
	   Nesta fase, se o Cheque de Pagamento for do Unibanco
	   pode-se vincula-lo a qualquer Cobranca/Arrecadacao.
	   Se o Cheque de Pagamento nao for do Unibanco
	   somente vincula-o se a Cobranca for diferente
	   de "Titulos Terceiros Sem CB" (12) e diferente de
	   "Cobranca Terceiros" (31)
	*/

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CP" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /*****************************************
            ' * Cheque ou ADCC a Verificar o Vinculo *
            ' ****************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.TipoGenerico == "CO" && 
					DocAux.Vinculo == 0 && 
					!DocAux.DesprezarVinculo &&
					Doc.Valor == DocAux.Valor )
				{
					if( (Doc.TipoDocto == 6 && DocAux.TipoDocto != 12 &&
						 DocAux.TipoDocto != 31) || Doc.TipoDocto == 5 ||
						 Doc.TipoDocto == 4 || Doc.TipoDocto == 41 )
					{
						/**********************************
						' * Vinculando Conta com o Cheque *
						' *********************************/
						m_ArrayDoc[i].Vinculo  = Doc.IdDocto;
						m_ArrayDoc[j].Vinculo  = Doc.IdDocto;
						/**************************************
						' * Corrige o tipodocumento do cheque *
						' *************************************/
						if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
						{
							if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230"))
							{
								m_ArrayDoc[i].TipoDocto = 5;
								if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
								{
									m_ArrayDoc[i].Alcada = TRUE;
								}
								else
								{
									m_ArrayDoc[i].Alcada = FALSE;
								}
							}
							else
							{
								m_ArrayDoc[i].TipoDocto = 6;
								if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
								{
									m_ArrayDoc[i].Alcada = TRUE;
								}
								else
								{
									m_ArrayDoc[i].Alcada = FALSE;
								}
							}
						}
						break;
					}
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /*********************************************
    ' * Verificando a Qtde de Contas no Envelope *
    ' * A Serem Vinculadas                       *
    ' *******************************************/
    iQtdContas = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CO" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdContas++;
	}

	if( iQtdContas == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return;
	}

	/* Comentario do Vagner:
	   Nesta segunda fase o algoritmo tenta vincular um cheque com
	   uma combinacao das contas, esta combinacao comeca com n, depois
	   tenta n-1, n-2, ...
	   Porem ele so testa combinacoes com documentos adjacentes, 
	   ele nao verifica todas as combinacoes possiveis.
	*/

	/* Comentario do Vagner:
	   Nesta fase, se, e somente se, o Cheque de Pagamento for 
	   do Unibanco pode-se vincula-lo a qualquer Cobranca/Arrecadacao.
	*/

    /*****************************************
    ' * Segunda Fase do Vinculo              *
    ' * Vinculando Um Cheque a v�rias Contas *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto == 4 || Doc.TipoDocto == 5 || Doc.TipoDocto == 41) && 
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /*****************************************
            ' * Cheque ou ADCC a Verificar o Vinculo *
            ' ****************************************/
			iInicio    = 1;
			iDesprezar = 1;
			while( iInicio <= iQtdContas )
			{
				ValorVinculo = 0;
				iConta       = 0;

				aIndConta.RemoveAll();
				for( j = 0; j < iQtdContas; j++ )
					aIndConta.Add(-1);

				for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
				{
					DocAux = m_ArrayDoc[j];
					if( DocAux.TipoGenerico == "CO" && 
						DocAux.Vinculo == 0 && 
						!DocAux.DesprezarVinculo )
					{
						iConta++;
						if( iConta == iInicio || iConta > iDesprezar )
						{
							ValorVinculo += DocAux.Valor;
							aIndConta[iConta-1] = j;
							if( ValorVinculo >= Doc.Valor )
								break;
						}
					}
				}
				if( iInicio % 50 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}

				/**********************************************
				 * Verifica se o Valor da Combinacao bate com *
				 * o valor do cheque, entao vincula           *
				 **********************************************/
				if( ValorVinculo == Doc.Valor )
				{
					m_ArrayDoc[i].Vinculo = Doc.IdDocto;
					/**************************************
					' * Corrige o tipodocumento do cheque *
					' *************************************/
					if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
					{
						if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230") )
						{
							m_ArrayDoc[i].TipoDocto = 5;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
						else
						{
							m_ArrayDoc[i].TipoDocto = 6;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
					}

					for( j = 0; j < iQtdContas; j++ )
					{
						if( aIndConta[j] >= 0 )
						{
							m_ArrayDoc[aIndConta[j]].Vinculo = Doc.IdDocto;
						}
					}
					break;
				}

				iDesprezar++;
				if( iDesprezar >= iQtdContas )
				{
					iInicio++;
					iDesprezar = iInicio;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

	/* Comentario do Vagner:
	   Se o processo chegou ate este ponto, entao tudo que poderia
	   ser vinculado 1 para 1 ou 1 para N ja foi vinculado.
	*/

    /**********************************************
    ' * Verificando a Qtde de Cheques no Envelope *
    ' * A Serem Vinculados                        *
    ' ********************************************/
    iQtdCheques = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto >= 4 && Doc.TipoDocto < 7 || Doc.TipoDocto == 41) &&
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdCheques++;
	}

	if( iQtdCheques == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return;
	}

	/* Comentario do Vagner:
	   Nesta parte, o processo vai tentar vincular um cheque para uma
	   conta mesmo que os valores nao batam, desde que a diferenca seja
	   menor ou igual a ValorAjusteContabil, e caso seja possivel vincular,
	   sera gerado o ajuste contabil.
	*/

    /*****************************************
    ' * Terceira Fase do Vinculo             *
    ' * Vinculando Um Cheque para Uma Conta  *
	' * com diferenca <= ValorAjusteContabil *
    ' ****************************************/

	/* Comentario do Vagner:
	   Nesta fase, se o Cheque de Pagamento for do Unibanco
	   pode-se vincula-lo a qualquer Cobranca/Arrecadacao.
	   Se o Cheque de Pagamento nao for do Unibanco
	   somente vincula-o se a Cobranca for diferente
	   de "Titulos Terceiros Sem CB" (12) e diferente de
	   "Cobranca Terceiros" (31)
	*/

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CP" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /*****************************************
            ' * Cheque ou ADCC a Verificar o Vinculo *
            ' ****************************************/
			for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
			{
				DocAux = m_ArrayDoc[j];
				if( DocAux.TipoGenerico == "CO" && 
					DocAux.Vinculo == 0 && 
					!DocAux.DesprezarVinculo &&
					abs(Doc.Valor - DocAux.Valor) > 0 &&
				    abs(Doc.Valor - DocAux.Valor) <= Converte(m_pParametro->m_ValorAjusteContabil) )
				{
					if( (Doc.TipoDocto == 6 && DocAux.TipoDocto != 12 &&
						 DocAux.TipoDocto != 31) || Doc.TipoDocto == 5 ||
						 Doc.TipoDocto == 4 || Doc.TipoDocto == 41)
					{
						/**********************************
						' * Vinculando Conta com o Cheque *
						' *********************************/
						m_ArrayDoc[i].Vinculo  = Doc.IdDocto;
						m_ArrayDoc[j].Vinculo  = Doc.IdDocto;
						/**************************************
						' * Corrige o tipodocumento do cheque *
						' *************************************/
						if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
						{
							if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230") )
							{
								m_ArrayDoc[i].TipoDocto = 5;
								if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
								{
									m_ArrayDoc[i].Alcada = TRUE;
								}
								else
								{
									m_ArrayDoc[i].Alcada = FALSE;
								}
							}
							else
							{
								m_ArrayDoc[i].TipoDocto = 6;
								if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
								{
									m_ArrayDoc[i].Alcada = TRUE;
								}
								else
								{
									m_ArrayDoc[i].Alcada = FALSE;
								}
							}
						}

						/*****************************************
						' * Gravando Ajuste de D�bito ou Cr�dito *
						' ****************************************/
						if( !InsereAjuste( (Doc.Valor > DocAux.Valor ? 42 : 43), 
										   0, "0", abs(Doc.Valor - DocAux.Valor), IdDocto ) )
						{
							return;
						}
						Ajuste.Alcada = FALSE;
						Ajuste.DesprezarVinculo = FALSE;
						Ajuste.IdDocto = IdDocto;
						Ajuste.TipoDocto = (Doc.Valor > DocAux.Valor ? 42 : 43);
						Ajuste.TipoGenerico = (Doc.Valor > DocAux.Valor ? "AC" : "AD");
						Ajuste.Valor = abs(Doc.Valor - DocAux.Valor);
						Ajuste.Vinculo = Doc.IdDocto;
						m_ArrayDoc.InsertAt(0, Ajuste, 1);

						break;
					}
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

    /*********************************************
    ' * Verificando a Qtde de Contas no Malote   *
    ' * A Serem Vinculadas                       *
    ' *******************************************/
    iQtdContas = 0;

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( Doc.TipoGenerico == "CO" && Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
			iQtdContas++;
	}

	if( iQtdContas == 0 )
	{
        /******************************************
        ' * N�o Existe Mais Documentos a Vincular *
        ' *****************************************/
		return;
	}

	/* Comentario do Vagner:
	   Nesta fase, se, e somente se, o Cheque de Pagamento for 
	   do Unibanco pode-se vincula-lo a qualquer Cobranca/Arrecadacao.
	*/

    /*****************************************
    ' * Quarta Fase do Vinculo               *
    ' * Vinculando Um Cheque a v�rias Contas *
	' * com diferenca <= ValorAjusteContabil *
    ' ****************************************/
	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		if( (Doc.TipoDocto == 4 || Doc.TipoDocto == 5 || Doc.TipoDocto == 41) && 
			Doc.Vinculo == 0 && !Doc.DesprezarVinculo )
		{
            /*********************************************
            ' * Cheque, LI ou ADCC a Verificar o Vinculo *
            ' ********************************************/
			iInicio    = 1;
			iDesprezar = 1;
			while( iInicio <= iQtdContas )
			{
				ValorVinculo = 0;
				iConta       = 0;

				aIndConta.RemoveAll();
				for( j = 0; j < iQtdContas; j++ )
					aIndConta.Add(-1);

				for( j = 0; j <= m_ArrayDoc.GetUpperBound(); j++ )
				{
					DocAux = m_ArrayDoc[j];
					if( DocAux.TipoGenerico == "CO" && 
						DocAux.Vinculo == 0 && 
						!DocAux.DesprezarVinculo )
					{
						iConta++;
						if( iConta == iInicio || iConta > iDesprezar )
						{
							ValorVinculo += DocAux.Valor;
							aIndConta[iConta-1] = j;
							if( abs(Doc.Valor - ValorVinculo) <= 
								Converte(m_pParametro->m_ValorAjusteContabil) )
								break;
						}
					}
				}
				if( iInicio % 50 == 0 )
				{
					PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
				}

				/*******************************************************
				 * Verifica se o Valor da Combinacao menos             *
				 * o valor do cheque, e menor que ValorAjusteContabil  *
				 *******************************************************/
				if( abs(Doc.Valor - ValorVinculo) > 0 &&
					abs(Doc.Valor - ValorVinculo) <= 
					Converte(m_pParametro->m_ValorAjusteContabil) )
				{
					m_ArrayDoc[i].Vinculo = Doc.IdDocto;
					/**************************************
					' * Corrige o tipodocumento do cheque *
					' *************************************/
					if( m_ArrayDoc[i].TipoDocto == 6 || m_ArrayDoc[i].TipoDocto == 7 )
					{
						if( m_ArrayDoc[i].Leitura.Left(3) == _T("409") || m_ArrayDoc[i].Leitura.Left(3) == _T("230") )
						{
							m_ArrayDoc[i].TipoDocto = 5;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcada_Mal : m_pParametro->m_ValorAlcada_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
						else
						{
							m_ArrayDoc[i].TipoDocto = 6;
							if(	m_ArrayDoc[i].Valor >= Converte((m_Capa.IdEnv_Mal == "M" ? m_pParametro->m_ValorAlcadaOutros_Mal : m_pParametro->m_ValorAlcadaOutros_Env)) )
							{
								m_ArrayDoc[i].Alcada = TRUE;
							}
							else
							{
								m_ArrayDoc[i].Alcada = FALSE;
							}
						}
					}

					for( j = 0; j < iQtdContas; j++ )
					{
						if( aIndConta[j] >= 0 )
						{
							m_ArrayDoc[aIndConta[j]].Vinculo = Doc.IdDocto;
						}
					}

					/*****************************************
					' * Gravando Ajuste de D�bito ou Cr�dito *
					' ****************************************/
					if( !InsereAjuste( (Doc.Valor > ValorVinculo ? 42 : 43), 
									   0, "0", abs(Doc.Valor - ValorVinculo), IdDocto ) )
					{
						return;
					}
					Ajuste.Alcada = FALSE;
					Ajuste.DesprezarVinculo = FALSE;
					Ajuste.IdDocto = IdDocto;
					Ajuste.TipoDocto = (Doc.Valor > ValorVinculo ? 42 : 43);
					Ajuste.TipoGenerico = (Doc.Valor > ValorVinculo ? "AC" : "AD");
					Ajuste.Valor = abs(Doc.Valor - ValorVinculo);
					Ajuste.Vinculo = Doc.IdDocto;
					m_ArrayDoc.InsertAt(0, Ajuste, 1);
					
					break;
				}

				iDesprezar++;
				if( iDesprezar >= iQtdContas )
				{
					iInicio++;
					iDesprezar = iInicio;
				}
			}
			if( i % 10 == 0 )
			{
				PeekMessage(&m_Msg, NULL, 0, 0, PM_NOREMOVE);
			}
		}
	}

}


BOOL CVinculador::AtualizaDocumentos( void )
{
	CString strSql;
	int i;
	DOCUMENTO Doc;

	
	m_oDB.BeginTrans();

	for( i = 0; i <= m_ArrayDoc.GetUpperBound(); i++ )
	{
		Doc = m_ArrayDoc[i];
		
		strSql.Format("Execute VA_AtualizaDocumento %ld, %ld, %d, %d, '%s'",
					  m_lDataProc, Doc.IdDocto, Doc.TipoDocto, 
					  Doc.Vinculo, (Doc.Alcada ? "S" : "N") );

		try
		{
			m_oDB.ExecuteSQL(LPCTSTR(strSql));
		}
		catch (CDBException *E)
		{
			//Armazena a informa��o sobre o erro
			strcpy(m_MsgError, LPCSTR(E->m_strError)); 
			strcat(m_MsgError, " (CGetDataProc.Open) ");
			m_iCodError= E->m_nRetCode;  

			m_oDB.Rollback();

			E->Delete(); 
			return FALSE;		
		}

	}

	m_oDB.CommitTrans();

	return TRUE;

}

BOOL CVinculador::DespachaCapa( void )
{
	BOOL bAlcada, bVinculado, bDifDeposito, bNovaRegraLI;
	__int64 ValorCredito, ValorDebito, ValorChDeposito, ValorDeposito;
	DOCUMENTO Doc;
	int i, j, k;

	ValorCredito	= 0;
	ValorDebito		= 0;
	ValorChDeposito = 0;
	ValorDeposito   = 0;
	bAlcada			= FALSE;
	bVinculado		= TRUE;
	bDifDeposito	= FALSE;
	bNovaRegraLI	= FALSE;
	
	i = 0;
	while( i <= m_ArrayDoc.GetUpperBound() )
	{
		Doc = m_ArrayDoc[i];
		
		if( Doc.TipoGenerico == "CO" || Doc.TipoDocto == 34 || Doc.TipoDocto == 42 )
		{
			ValorCredito += Doc.Valor;
		}
		else if( Doc.TipoGenerico == "CP" || Doc.TipoDocto == 38 || Doc.TipoDocto == 43 )
		{
			ValorDebito += Doc.Valor;
		}
		else if( Doc.TipoGenerico == "DE" )
		{

			ValorDeposito = Doc.Valor;
			ValorChDeposito = 0;
			/**************************************
			  Verifica se est� na Nova Regra do LI
			**************************************/
			if( bNovaRegraLI == FALSE )
			{
				j = i + 1;
				while( j <= m_ArrayDoc.GetUpperBound() )
				{
					//if( m_ArrayDoc[j].TipoGenerico == "DE" || m_ArrayDoc[j].TipoDocto == 32 )
					if( m_ArrayDoc[j].TipoGenerico == "DE" ||
						m_ArrayDoc[j].TipoGenerico == "OC" )
					{
						ValorDeposito += m_ArrayDoc[j].Valor;
						j++;
						continue;
					}
					/******************************
					  � um LI seguido de Depositos
					******************************/
					else if( m_ArrayDoc[j].TipoGenerico == "CP" && m_ArrayDoc[j].TipoDocto == 41 )
					{
						/******************************
						  Procura agora somente contas
						******************************/
						ValorChDeposito = m_ArrayDoc[j].Valor;
						bNovaRegraLI = TRUE;

						if( m_ArrayDoc[j].Alcada )
							bAlcada = TRUE;

						if( m_ArrayDoc[j].Vinculo == 0 )
							bVinculado = FALSE;

						k = j + 1;
						//ValorCredito = 0;
						while( k <= m_ArrayDoc.GetUpperBound() )
						{
							if( (m_ArrayDoc[k].TipoGenerico != "CO") &&
								(m_ArrayDoc[k].TipoGenerico != "AD") &&
								(m_ArrayDoc[k].TipoGenerico != "AC"))
							{
								bNovaRegraLI = FALSE;
								break;
							}
							else
							{
								if( m_ArrayDoc[k].TipoGenerico == "AD" )
									ValorCredito -= m_ArrayDoc[k].Valor;
								else
									ValorCredito += m_ArrayDoc[k].Valor;
							}
							k++;
						}
					}
					/*************************
					  N�o est� na Regra do LI
					*************************/
					break;
				}
			}

			if( bNovaRegraLI == FALSE )
			{
				for( j = i + 1; j<= m_ArrayDoc.GetUpperBound(); j++ )
				{
					if( m_ArrayDoc[j].TipoGenerico == "CD" ||
						m_ArrayDoc[j].TipoDocto == 33 || m_ArrayDoc[j].TipoDocto == 41 ) 
					{
						ValorChDeposito += m_ArrayDoc[j].Valor;
					}
					else if( m_ArrayDoc[j].TipoDocto == 32 )
					{
						ValorDeposito += m_ArrayDoc[j].Valor;
					}
					else
					{
						break;
					}
				}
				if( !bDifDeposito && ValorChDeposito != ValorDeposito )
				{
					bDifDeposito = TRUE;
				}
			}
			else
			{
				//if( !bDifDeposito && ValorChDeposito != (ValorDeposito + ValorCredito) )
				if( !bDifDeposito && (ValorChDeposito + ValorDebito) != (ValorDeposito + ValorCredito) )
				{
					bDifDeposito = TRUE;
				}
			}
			i = j - 1;
		}
		
		if( Doc.Alcada )
			bAlcada = TRUE;

		if( Doc.Vinculo == 0 )
			bVinculado = FALSE;

		i++;

		if( bNovaRegraLI ) break;
	}

	m_Capa.Diferenca = (ValorChDeposito + ValorDebito) - (ValorDeposito + ValorCredito);

	if( m_Capa.Diferenca != 0 )
	{
		if( !m_Capa.GerarAjuste || bNovaRegraLI)
		{
			// Enviar para Prova Zero
			m_Capa.Status = "4";
		}
		else
		{
			// Enviar para Vinculo Manual
			m_Capa.Status = "7";
		}
	}
	else if( m_Capa.Diferenca == 0 && bDifDeposito )
	{
		// Enviar para Vinculo Automatico
		m_Capa.Status = "9";
	}
//	else if( m_Capa.Diferenca == 0 && bVinculado && !bAlcada)
//	{
		// Enviar para Transmiss�o
//		m_Capa.Status = "R";

		// Envia Nova Regra do Lan�amento 
		//Interno para Al�ada
		//if( bNovaRegraLI && bAlcada )
		//	m_Capa.Status = "6";
//	}
	else if( !bVinculado )
	{
		// Enviar para Vinculo Manual
		m_Capa.Status = "7";
	}
	else if( bAlcada )
	{
		// Enviar para Alcada
		m_Capa.Status = "6";
	}
	else
	{
		// Enviar para Transmissao
		m_Capa.Status = "R";
	}

	if( AtualizaStatusCapa() )
		return TRUE;
	else
		return FALSE;
}

__int64 CVinculador::Converte( CString Valor )
{
	CString Result;
	int Pos;

	Pos = Valor.Find( '.' );
	if( Pos == -1 )
	{
		Result = Valor;
	}
	else
	{
		Result = Valor.Left(Pos) + Valor.Mid(Pos + 1, 2);
	}
	return _atoi64(LPCTSTR(Result));
}

BOOL CVinculador::RemoveAjustes( void )
{
	CString strSql;

	strSql.Format("Execute RemoveAjusteCapa %ld, %ld", m_lDataProc, m_Capa.IdCapa);

	try
	{
		m_oDB.ExecuteSQL(LPCTSTR(strSql));
	}
	catch (CDBException *E)
	{
		//Armazena a informa��o sobre o erro
		strcpy(m_MsgError, LPCSTR(E->m_strError)); 
		strcat(m_MsgError, " (RemoveAjusteCapa) ");
		m_iCodError= E->m_nRetCode;  

		E->Delete(); 
		return FALSE;		
	}
	return TRUE;
}


BOOL CVinculador::InsereLog( short Acao )
{
	CString strSql;

	strSql.Format("Execute InsereLog %ld, %ld, 0, 'Vinculo', %d",
				  m_lDataProc, m_Capa.IdCapa, Acao);

	try
	{
		m_oDB.ExecuteSQL(LPCTSTR(strSql));
	}
	catch (CDBException *E)
	{
		//Armazena a informa��o sobre o erro
		strcpy(m_MsgError, LPCSTR(E->m_strError)); 
		strcat(m_MsgError, " (InsereLog) ");
		m_iCodError= E->m_nRetCode;  

		E->Delete(); 
		return FALSE;		
	}
	return TRUE;
}

BOOL CVinculador::PossuiDocumentoTransmitido( void )
{
	CGetDocumentoTransmitido m_DocTransmitido(&m_oDB);

	while( true )
	{
		try
		{
			if( m_DocTransmitido.IsOpen() )
				m_DocTransmitido.Close();

			m_DocTransmitido.m_DataProc = m_lDataProc;
			m_DocTransmitido.m_IdCapa   = m_Capa.IdCapa;
			if( !m_DocTransmitido.Open( CRecordset::snapshot, NULL ) )
			{
				//Armazena a informa��o sobre o erro
				strcpy(m_MsgError, "Erro na obten��o na Qtde de Documentos Transmitidos. (CGetDocumentoTransmitido.Open)"); 
				m_iCodError= 100;  
				return FALSE;
			}
			if( m_DocTransmitido.m_Qtde > 0)
			{
				// So exitem documentos transmitidos
				// Enviar para verificacao
				m_Capa.Status = "V";
				m_DocTransmitido.Close();
				return TRUE;
			}
			else
			{
				m_DocTransmitido.Close();
				return FALSE;
			}
		}
		catch(CDBException *E)
		{
			//Armazena a informa��o sobre o erro
			strcpy(m_MsgError, LPCSTR(E->m_strError)); 
			strcat(m_MsgError, " (CGetDocumentoTransmitido.Open) ");
			m_iCodError= E->m_nRetCode;  
			E->Delete(); 

			if( memcmp(m_MsgError, "Timeout expired", 15) != 0 )
			{
				return FALSE;		
			}
			else
				continue;
		}
	}
}



BOOL CVinculador::NovaRegraLancamentoInterno( void )
{
	DOCUMENTO Doc;
	int       i, j;

	i             = 0;
	j             = 0;

	while( m_ArrayDoc[i].TipoGenerico == "DE" )
	{
		i++;
	}

	if( m_ArrayDoc[i].TipoGenerico == "CP" && m_ArrayDoc[i].TipoDocto == 41)
	{
		for( j = i + 1; j <= m_ArrayDoc.GetUpperBound(); j++)
		{
			if ( m_ArrayDoc[j].TipoGenerico != "CO" )
			{
				return FALSE;
			}
		}
	}
	else
	{
		return FALSE;
	}


	return TRUE;
}